var a00004 =
[
    [ "BLE Peripheral", "a00058.html", "a00058" ],
    [ "BLE DFU Bootloader", "a00078.html", "a00078" ],
    [ "Direct Test Mode", "a00056.html", [
      [ "BLE DTM module interface", "a00056.html#ble_sdk_dtm_lib_interface", null ],
      [ "Vendor Specific Packet Payload", "a00056.html#ble_sdk_dtm_proprietary", null ],
      [ "The DTM to Serial adaptation layer", "a00056.html#ble_sdk_dtm_serial2w", null ],
      [ "Running DTM tests", "a00056.html#ble_sdk_dtm_testing", null ]
    ] ],
    [ "Hardware Peripheral Examples", "a00029.html", "a00029" ],
    [ "Nordic proprietary protocols", "a00114.html", "a00114" ],
    [ "BSP indication states", "a00057.html", null ]
];