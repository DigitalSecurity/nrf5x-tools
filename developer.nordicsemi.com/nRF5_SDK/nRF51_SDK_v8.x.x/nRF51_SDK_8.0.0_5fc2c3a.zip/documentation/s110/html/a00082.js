var a00082 =
[
    [ "Example application", "a00080.html", [
      [ "Testing the example with bonding", "a00080.html#bledfu_appexample_bonding", null ],
      [ "Testing the example without bonding", "a00080.html#bledfu_appexample_nobonding", null ]
    ] ],
    [ "Extending your application", "a00081.html", [
      [ "Including DFU files in application", "a00081.html#app_dfu_files_sec", null ],
      [ "Implementing graceful shutdown", "a00081.html#app_dfu_reset", null ],
      [ "Setting up the BLE services", "a00081.html#bledfu_ble_services", [
        [ "Initializing the DFU Service", "a00081.html#app_dfu_service_sec", null ],
        [ "Enabling the Service Changed characteristic", "a00081.html#bledfu_scc", null ],
        [ "Updating the Device Manager configuration", "a00081.html#bledfu_dm_config", null ]
      ] ],
      [ "Propagating BLE stack events", "a00081.html#app_dfu_prop_events", null ]
    ] ],
    [ "Switching to bootloader/DFU mode", "a00083.html", null ],
    [ "Sharing bonding information", "a00079.html", [
      [ "Implementation", "a00079.html#bledfu_appbonding_impl", null ]
    ] ]
];