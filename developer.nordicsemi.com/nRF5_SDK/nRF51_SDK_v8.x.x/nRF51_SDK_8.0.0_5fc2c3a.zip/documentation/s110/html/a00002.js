var a00002 =
[
    [ "LPCOMP", "a00007.html", null ],
    [ "UART", "a00015.html", null ],
    [ "TWI", "a00014.html", null ],
    [ "SPI Master", "a00011.html", [
      [ "SPI Module Initialization and Configuration", "a00011.html#spi_master_init", null ],
      [ "SPI Master Data Exchange API", "a00011.html#spi_master_send_recv", null ]
    ] ],
    [ "SPI Slave", "a00012.html", null ],
    [ "Timer", "a00013.html", null ],
    [ "QDEC", "a00009.html", null ],
    [ "Clock", "a00006.html", null ],
    [ "RNG", "a00010.html", null ],
    [ "WDT", "a00016.html", null ],
    [ "PPI", "a00008.html", null ]
];