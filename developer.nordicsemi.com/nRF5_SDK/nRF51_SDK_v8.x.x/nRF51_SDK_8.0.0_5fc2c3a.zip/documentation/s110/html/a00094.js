var a00094 =
[
    [ "Relocating the bootloader", "a00095.html", null ],
    [ "Dual-bank and single-bank updates", "a00088.html", [
      [ "Dual-bank updates", "a00088.html#bledfu_dual_bank", [
        [ "SoftDevice (with or without bootloader)", "a00088.html#bledfu_dual_banks_sd", null ],
        [ "Application or bootloader", "a00088.html#bledfu_dual_banks_app", null ]
      ] ],
      [ "Single-bank updates", "a00088.html#bledfu_single_bank", null ]
    ] ],
    [ "Preserving application data", "a00090.html", null ]
];