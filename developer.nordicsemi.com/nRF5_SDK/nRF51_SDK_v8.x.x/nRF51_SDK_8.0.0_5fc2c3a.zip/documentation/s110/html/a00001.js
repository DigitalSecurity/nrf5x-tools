var a00001 =
[
    [ "Running a first example", "a00018.html", null ],
    [ "Running examples that use a SoftDevice", "a00017.html", [
      [ "nRFgo Studio", "a00017.html#getting_started_sd_studio", null ],
      [ "ARM Keil", "a00017.html#getting_started_sd_keil", null ],
      [ "GCC makefile", "a00017.html#getting_started_sd_gcc", null ]
    ] ],
    [ "Using the SDK with other boards", "a00028.html", [
      [ "Supported boards", "a00028.html#supported_board", null ],
      [ "Enabling support for a board", "a00028.html#bsp_location", null ],
      [ "Adding support for a custom board", "a00028.html#custom_board_support", null ]
    ] ]
];