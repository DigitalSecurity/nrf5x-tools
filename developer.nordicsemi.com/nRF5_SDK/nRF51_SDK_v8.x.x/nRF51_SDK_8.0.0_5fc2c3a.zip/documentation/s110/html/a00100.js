var a00100 =
[
    [ "RTX Support", "a00101.html", [
      [ "Limitations", "a00101.html#rtx_limitation", null ],
      [ "Cooperation with the SoftDevice", "a00101.html#rtx_softdevice", null ],
      [ "Examples", "a00101.html#rtx_interrupt", null ]
    ] ]
];