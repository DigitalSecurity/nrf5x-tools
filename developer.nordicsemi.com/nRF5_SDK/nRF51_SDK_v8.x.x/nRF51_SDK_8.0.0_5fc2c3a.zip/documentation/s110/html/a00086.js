var a00086 =
[
    [ "Architecture of the DFU bootloader", "a00084.html", null ],
    [ "Architecture of the DFU process", "a00085.html", null ],
    [ "DFU state machine", "a00087.html", null ]
];