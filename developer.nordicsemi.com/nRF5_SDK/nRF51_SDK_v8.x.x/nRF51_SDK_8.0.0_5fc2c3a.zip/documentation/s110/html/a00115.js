var a00115 =
[
    [ "Advertising Data Encoder", "a00117.html", null ],
    [ "Debug Assert Handler", "a00118.html", null ],
    [ "BLE Device Manager", "a00124.html", [
      [ "Initialization", "a00124.html#lib_device_manaegerit", [
        [ "Associated Events", "a00124.html#lib_device_manager_init_evt", null ],
        [ "Associated Configuration Parameters", "a00124.html#lib_device_manager_init_cnfg_param", null ]
      ] ],
      [ "Registration", "a00124.html#lib_device_manager_register", [
        [ "Associated Events", "a00124.html#lib_cnxn_register_evt", null ],
        [ "Associated Configuration Parameters", "a00124.html#lib_cnxn_register_cnfg_param", null ]
      ] ]
    ] ],
    [ "Advertising Module", "a00020.html", [
      [ "Advertising modes", "a00020.html#adv_modes", null ],
      [ "Whitelist", "a00020.html#whitelist", null ],
      [ "Usage", "a00020.html#interaction", null ]
    ] ],
    [ "Connection Parameters Negotiation", "a00119.html", [
      [ "Overview", "a00119.html#Overview", null ],
      [ "Initialization and Set-up", "a00119.html#lib_ble_conn_params_init", null ],
      [ "Shutdown", "a00119.html#lib_ble_conn_params_stop", null ],
      [ "Change/Update Connection Parameters Negotiated", "a00119.html#lib_ble_conn_params_change_conn_params", null ]
    ] ],
    [ "DTM - Direct Test Mode", "a00120.html", null ],
    [ "Error Log", "a00121.html", null ],
    [ "Record Access Control Point", "a00122.html", null ],
    [ "Radio Notification Event Handler", "a00123.html", null ]
];