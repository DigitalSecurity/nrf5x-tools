var a00116 =
[
    [ "Alert Notification Service Client", "a00125.html", null ],
    [ "Battery Service", "a00126.html", null ],
    [ "Blood Pressure Service", "a00127.html", null ],
    [ "Cycling Speed and Cadence Service", "a00128.html", null ],
    [ "Device Information Service", "a00129.html", null ],
    [ "Glucose Service", "a00130.html", [
      [ "Glucose Service", "a00130.html#section_glucose_service", null ],
      [ "Glucose Service Database", "a00130.html#section_glucose_service_db", null ]
    ] ],
    [ "Health Thermometer Service", "a00131.html", null ],
    [ "Heart Rate Service", "a00132.html", null ],
    [ "Human Interface Device Service", "a00133.html", null ],
    [ "Human Immediate Alert Service", "a00134.html", null ],
    [ "Human Immediate Alert Service Client", "a00135.html", null ],
    [ "Link Loss Service", "a00136.html", null ],
    [ "Running Speed and Cadence Service", "a00137.html", null ],
    [ "TX Power Service", "a00138.html", null ]
];