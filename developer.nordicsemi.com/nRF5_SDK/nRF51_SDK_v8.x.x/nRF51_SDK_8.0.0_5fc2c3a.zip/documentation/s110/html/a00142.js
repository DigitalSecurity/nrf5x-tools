var a00142 =
[
    [ "HCI transport library", "a00143.html", null ],
    [ "Memory pool library", "a00144.html", null ],
    [ "SLIP handling library", "a00145.html", null ]
];