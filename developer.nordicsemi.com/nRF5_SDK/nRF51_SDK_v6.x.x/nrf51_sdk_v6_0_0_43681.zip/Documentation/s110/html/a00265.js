var a00265 =
[
    [ "gatt_status", "a00265.html#a76066ec0dfed065ff7e58a709eaf8042", null ],
    [ "len", "a00265.html#a5242203755359060a29308d0e64b6da7", null ],
    [ "offset", "a00265.html#a7b823765dc8e01aa1dfc9a3124f92bc9", null ],
    [ "p_data", "a00265.html#a777067adc297b1e3fa67a4671663ba2f", null ],
    [ "update", "a00265.html#a27015e208127d98d0600657e4f9224fc", null ]
];