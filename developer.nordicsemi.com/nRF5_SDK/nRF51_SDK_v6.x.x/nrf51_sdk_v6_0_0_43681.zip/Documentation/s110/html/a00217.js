var a00217 =
[
    [ "addr", "a00217.html#abbebf4e8f11e077613a36c7426e7218a", null ],
    [ "irk", "a00217.html#a72555f9ff6f6160e58b420d743633f9f", null ]
];