var a00004 =
[
    [ "BLE Peripheral", "a00091.html", "a00091" ],
    [ "Bootloader/DFU", "a00055.html", "a00055" ],
    [ "Direct Test Mode", "a00063.html", [
      [ "Direct Test Mode", "a00063.html#project_dtm_intro", null ],
      [ "BLE DTM module interface", "a00063.html#ble_sdk_dtm_lib_interface", null ],
      [ "Vendor Specific Packet Payload", "a00063.html#ble_sdk_dtm_proprietary", null ],
      [ "The DTM to Serial adaptation layer", "a00063.html#ble_sdk_dtm_serial2w", null ],
      [ "Running DTM tests", "a00063.html#ble_sdk_dtm_testing", null ]
    ] ],
    [ "Hardware Peripheral Examples", "a00024.html", "a00024" ],
    [ "Nordic proprietary protocols", "a00122.html", "a00122" ]
];