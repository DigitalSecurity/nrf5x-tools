var a00147 =
[
    [ "channel", "a00147.html#a5e084957ed6c0f93b78203d74a268e36", null ],
    [ "event", "a00147.html#a8449b66e97f4dfce737478dc751199e1", null ],
    [ "evt_buffer", "a00147.html#a0945895af053724b710662f5beea9ed5", null ]
];