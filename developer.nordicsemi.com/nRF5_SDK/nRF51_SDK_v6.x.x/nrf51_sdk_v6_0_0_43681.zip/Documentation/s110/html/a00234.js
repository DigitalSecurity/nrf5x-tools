var a00234 =
[
    [ "chars", "a00234.html#aae5e676db57239ee9cfe89c13f603dd0", null ],
    [ "count", "a00234.html#a91337d714a569e896c896a3b255db8ff", null ]
];