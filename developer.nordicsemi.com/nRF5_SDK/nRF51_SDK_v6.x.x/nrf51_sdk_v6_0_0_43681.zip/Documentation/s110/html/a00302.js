var a00302 =
[
    [ "alert_level_handles", "a00302.html#aee2e9a72478596b53d8d99a398360591", null ],
    [ "error_handler", "a00302.html#a4a22ac8304ea3a4bc7dacb72a8d65bc0", null ],
    [ "evt_handler", "a00302.html#a331d5f75c24c9f4be6b9f4464ce828c9", null ],
    [ "service_handle", "a00302.html#ae8ad660b1350238c9bb1f4ff6e043ef7", null ]
];