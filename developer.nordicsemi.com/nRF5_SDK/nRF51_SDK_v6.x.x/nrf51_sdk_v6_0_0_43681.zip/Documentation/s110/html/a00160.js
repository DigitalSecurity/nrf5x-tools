var a00160 =
[
    [ "alert_category", "a00160.html#afa8fc29bec3beb7c27a5b8638273c811", null ],
    [ "alert_category_count", "a00160.html#a92d6452f642f4010d2a45eaa6e2de420", null ],
    [ "alert_msg_length", "a00160.html#afdc318698fc9128ebe8f068b6350c4ec", null ],
    [ "p_alert_msg_buf", "a00160.html#aa8b8813b3a0e089e79b4c48d05d46001", null ]
];