var a00281 =
[
    [ "char_handles", "a00281.html#a3f137cc3f92bf439d93a8491e4314d5a", null ],
    [ "ref_handle", "a00281.html#a0209468bba2c298192f4500a652dd6d1", null ]
];