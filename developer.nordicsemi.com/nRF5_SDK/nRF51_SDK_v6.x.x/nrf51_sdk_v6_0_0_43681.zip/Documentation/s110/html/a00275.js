var a00275 =
[
    [ "char_auth_read", "a00275.html#a52453afb42d527bc45516dc3f2956263", null ],
    [ "char_id", "a00275.html#a778ecea962888dfc1e026fc52526a9a4", null ],
    [ "char_write", "a00275.html#acb0dff54d056df773cad96ecfb415bce", null ],
    [ "data", "a00275.html#a8c305e6a62b2c26934d5be6e84dec0f5", null ],
    [ "evt_type", "a00275.html#a51d0ccfb2582557e1863bb12d77e71dc", null ],
    [ "len", "a00275.html#ae218ffb7a01687ebe2557a2ab2d48bba", null ],
    [ "notification", "a00275.html#a58294e1cb350129aeec706402e8fcc0a", null ],
    [ "offset", "a00275.html#ab8048550dc2672f019c4e6278977efbc", null ],
    [ "p_ble_evt", "a00275.html#a43346ee583a9d322a18716f188630a89", null ],
    [ "params", "a00275.html#a2ac2fca86fa63145eb52d2f3840bb8a3", null ]
];