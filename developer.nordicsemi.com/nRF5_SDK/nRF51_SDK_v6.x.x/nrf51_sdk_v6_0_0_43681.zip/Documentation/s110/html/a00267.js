var a00267 =
[
    [ "gatt_status", "a00267.html#a1e360fe54c33885b6e23e57c483f6959", null ]
];