var a00238 =
[
    [ "data", "a00238.html#af239b9ba3cff6d1fc678f3f71711a2f3", null ],
    [ "handle", "a00238.html#a96ee6ce1546af608cf4b3b9d81cd7f09", null ],
    [ "len", "a00238.html#a173be268109e2223c485a9a10a6a9ba3", null ],
    [ "type", "a00238.html#ac1de2368e40b7e4c7eab1fcb770605f2", null ]
];