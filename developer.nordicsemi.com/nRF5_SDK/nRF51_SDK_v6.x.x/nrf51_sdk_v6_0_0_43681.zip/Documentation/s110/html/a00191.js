var a00191 =
[
    [ "manufacturer_id", "a00191.html#ae1f58152dab08532bc52edd976c2f51c", null ],
    [ "organizationally_unique_id", "a00191.html#a452099e99c407f16e24299e57e53af46", null ]
];