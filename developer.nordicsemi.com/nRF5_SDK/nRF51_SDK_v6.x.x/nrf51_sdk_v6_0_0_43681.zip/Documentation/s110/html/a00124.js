var a00124 =
[
    [ "Alert Notification Service Client", "a00133.html", null ],
    [ "Battery Service", "a00134.html", null ],
    [ "Blood Pressure Service", "a00135.html", null ],
    [ "Cycling Speed and Cadence Service", "a00136.html", null ],
    [ "Device Information Service", "a00137.html", null ],
    [ "Glucose Service", "a00138.html", [
      [ "Glucose Service", "a00138.html#section_glucose_service", null ],
      [ "Glucose Service Database", "a00138.html#section_glucose_service_db", null ]
    ] ],
    [ "Health Thermometer Service", "a00139.html", null ],
    [ "Heart Rate Service", "a00140.html", null ],
    [ "Human Interface Device Service", "a00141.html", null ],
    [ "Human Immediate Alert Service", "a00142.html", null ],
    [ "Human Immediate Alert Service Client", "a00143.html", null ],
    [ "Link Loss Service", "a00144.html", null ],
    [ "Running Speed and Cadence Service", "a00145.html", null ],
    [ "TX Power Service", "a00146.html", null ]
];