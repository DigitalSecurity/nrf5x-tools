var a00192 =
[
    [ "gatts_enable_params", "a00192.html#ad2de18bc975930cadc754c5e3468c870", null ]
];