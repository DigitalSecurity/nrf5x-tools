var a00266 =
[
    [ "params", "a00266.html#a402025fb277d33e15f1fa918bca15768", null ],
    [ "read", "a00266.html#a7d0c5d0586fa2a048d724a7ededf5e18", null ],
    [ "type", "a00266.html#a70efda4990b7c7e43bc7c0b1ae75c05e", null ],
    [ "write", "a00266.html#aa536efc6b3a866b5ae2d4c6cd9b2aafa", null ]
];