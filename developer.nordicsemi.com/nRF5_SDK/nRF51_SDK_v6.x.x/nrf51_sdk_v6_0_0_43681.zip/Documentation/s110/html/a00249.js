var a00249 =
[
    [ "flags", "a00249.html#ae9bf42dc0e530824c93ec423e6539220", null ],
    [ "handle", "a00249.html#a4b5cec7a8b33f482114d99026b2ee92d", null ],
    [ "len", "a00249.html#a068c40f218ed3932901529ac05b69c21", null ],
    [ "offset", "a00249.html#a85d01254a43068218061ab21acabe980", null ],
    [ "p_value", "a00249.html#a361b91f9ee1961598bc9c94520f8004b", null ],
    [ "write_op", "a00249.html#a2c42a23118699b0fab8f49f1d9b4b386", null ]
];