var a00114 =
[
    [ "Device/Host example", "a00116.html", [
      [ "Host", "a00116.html#Host", null ],
      [ "Device", "a00116.html#Device", null ]
    ] ],
    [ "Desktop device emulator", "a00115.html", null ],
    [ "Pairing Device with Dynamic Pairing", "a00117.html", [
      [ "Device pairing", "a00117.html#gzll_example_gzp_pairing_section_device", null ],
      [ "Host pairing", "a00117.html#gzll_example_gzp_pairing_section_host", null ]
    ] ]
];