var a00233 =
[
    [ "handle", "a00233.html#ada1f0c9228867fd73fd596d6d7241c67", null ],
    [ "uuid", "a00233.html#a039854704d107784b185fb11b00b1258", null ]
];