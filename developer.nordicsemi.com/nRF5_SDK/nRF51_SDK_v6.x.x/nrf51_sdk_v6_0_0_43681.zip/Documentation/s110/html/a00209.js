var a00209 =
[
    [ "conn_params", "a00209.html#a0b48983984c9a6eca0b81380f8af8a05", null ],
    [ "irk_match", "a00209.html#ade7ff1956c46e2832bf82c95711a408f", null ],
    [ "irk_match_idx", "a00209.html#a40ac77b4be795c7085f8eece5adc9d73", null ],
    [ "peer_addr", "a00209.html#a2107b9536488cbcb75ca3f059e5ab72e", null ]
];