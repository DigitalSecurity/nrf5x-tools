var a00111 =
[
    [ "SPI RAW protocol", "a00107.html", [
      [ "SPI RAW protocol", "a00107.html#SPI_RAW_PROTOCOL", null ],
      [ "SPI RAW - packet writing", "a00107.html#SPI_RAW_BUS_TX", null ],
      [ "SPI RAW - packet reading", "a00107.html#SPI_RAW_BUS_RX", null ],
      [ "Master device driver", "a00107.html#SPI_RAW_DRIVER_MASTER", null ],
      [ "Slave device driver", "a00107.html#SPI_RAW_DRIVER_SLAVE", null ]
    ] ],
    [ "SPI_5W RAW protocol", "a00108.html", [
      [ "The implementation of SPI_5W RAW protocol has an 'experimental' status.", "a00108.html#SPI_5W_STATUS", null ],
      [ "SPI_5W RAW Protocol", "a00108.html#SPI_5W_RAW_PROTOCOL", null ],
      [ "SPI_5W RAW - packet writing", "a00108.html#SPI_5W_RAW_BUS_TX", null ],
      [ "SPI_5W RAW packet reading", "a00108.html#SPI_5W_RAW_BUS_RX", null ],
      [ "master device driver", "a00108.html#SPI_5W_RAW_DRIVER_MASTER", null ],
      [ "slave device driver", "a00108.html#SPI_5W_RAW_DRIVER_SLAVE", null ]
    ] ],
    [ "UART RAW protocol", "a00109.html", [
      [ "UART RAW protocol", "a00109.html#UART_RAW_PROTOCOL", null ],
      [ "UART RAW packet", "a00109.html#UART_RAW_PACKET", null ],
      [ "UART driver", "a00109.html#UART_RAW_DRIVER", null ]
    ] ],
    [ "UART STM RAW protocol", "a00110.html", [
      [ "UART STM RAW protocol", "a00110.html#UART_STM", null ]
    ] ]
];