var a00123 =
[
    [ "Advertising Data Encoder", "a00125.html", null ],
    [ "Debug Assert Handler", "a00126.html", null ],
    [ "Connection Parameters Negotiation", "a00127.html", [
      [ "Overview", "a00127.html#Overview", null ],
      [ "Initialization and Set-up", "a00127.html#lib_ble_conn_params_init", null ],
      [ "Shutdown", "a00127.html#lib_ble_conn_params_stop", null ],
      [ "Change/Update Connection Parameters Negotiated", "a00127.html#lib_ble_conn_params_change_conn_params", null ]
    ] ],
    [ "DTM - Direct Test Mode", "a00128.html", null ],
    [ "Error Log", "a00129.html", null ],
    [ "Record Access Control Point", "a00130.html", null ],
    [ "Radio Notification Event Handler", "a00131.html", null ],
    [ "Sensor Data Simulator", "a00132.html", null ]
];