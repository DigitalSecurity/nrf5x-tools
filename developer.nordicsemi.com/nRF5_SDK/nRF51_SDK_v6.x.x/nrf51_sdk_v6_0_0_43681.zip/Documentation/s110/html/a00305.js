var a00305 =
[
    [ "opcode", "a00305.html#ac9347eb17ef67e3f06df043008ffb2fc", null ],
    [ "operand_len", "a00305.html#af49baa0004db22db129862b609928a62", null ],
    [ "operator", "a00305.html#a3d079df679dec85ecc10fe70a2d349f1", null ],
    [ "p_operand", "a00305.html#a2560ddd094bfd6960dd5cc3a6ee54c48", null ]
];