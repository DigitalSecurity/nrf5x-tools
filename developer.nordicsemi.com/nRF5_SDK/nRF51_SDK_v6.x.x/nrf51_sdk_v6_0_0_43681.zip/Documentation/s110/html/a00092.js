var a00092 =
[
    [ "Architecture", "a00092.html#nrf51_arch_serialization", null ],
    [ "Serialization Setup", "a00094.html", null ],
    [ "BLE S110 Connectivity Chip", "a00093.html", null ],
    [ "BLE Serialization Codecs", "a00095.html", "a00095" ],
    [ "Serialization PHY", "a00111.html", "a00111" ]
];