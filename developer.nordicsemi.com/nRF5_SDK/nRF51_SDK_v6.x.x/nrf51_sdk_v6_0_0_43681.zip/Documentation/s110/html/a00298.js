var a00298 =
[
    [ "conn_handle", "a00298.html#ab843f6e96efbaf3d2bffee8c92c62f1a", null ],
    [ "params", "a00298.html#ac9beac1420f25dbd4bd49bb88bc2302d", null ],
    [ "rx", "a00298.html#afc4cbc758b308e6698b16650310cc52b", null ]
];