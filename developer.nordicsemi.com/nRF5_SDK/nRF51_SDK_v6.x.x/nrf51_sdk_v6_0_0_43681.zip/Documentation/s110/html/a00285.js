var a00285 =
[
    [ "evt_handler", "a00285.html#aa86b9c7d2205607e9e77fa9c3affabbe", null ],
    [ "hrs_bsl_attr_md", "a00285.html#a12b40292268a248ca7341f0298d16b1a", null ],
    [ "hrs_hrm_attr_md", "a00285.html#a8023c653b5f45b8fd6de1fc61761275a", null ],
    [ "is_sensor_contact_supported", "a00285.html#af531586afe7aa4c124e96e04d42e70d1", null ],
    [ "p_body_sensor_location", "a00285.html#a6950ba718a00b8236331be362d3a9beb", null ]
];