var a00248 =
[
    [ "handle_range", "a00248.html#ab54f33f930899f4e27df1d5819670958", null ],
    [ "uuid", "a00248.html#a3f00e5eb4b0f87085de2ea1e9464258b", null ]
];