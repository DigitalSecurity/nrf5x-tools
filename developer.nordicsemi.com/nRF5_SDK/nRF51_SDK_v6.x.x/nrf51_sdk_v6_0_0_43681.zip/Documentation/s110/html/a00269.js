var a00269 =
[
    [ "error_handler", "a00269.html#a60dd2e384291225af96e549356836e96", null ],
    [ "evt_handler", "a00269.html#a30ba6c48423cf07609a21bc2de05ece9", null ],
    [ "feature", "a00269.html#aa6db8884060986d835bd1e6aadffc770", null ],
    [ "is_context_supported", "a00269.html#a10d72eae94458d3d33788faf4099893c", null ]
];