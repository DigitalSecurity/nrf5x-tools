var a00237 =
[
    [ "count", "a00237.html#a50815a26acf0eaa4a6d7ef9bebf7f58d", null ],
    [ "descs", "a00237.html#a3d41c7255fa19fa2b55acd6962be26ee", null ]
];