var a00247 =
[
    [ "handle", "a00247.html#ab1f14809099e66b0dc7a4a70cb3dc124", null ],
    [ "included_srvc", "a00247.html#a3342baabc3197898f17ce875e7a5ba80", null ]
];