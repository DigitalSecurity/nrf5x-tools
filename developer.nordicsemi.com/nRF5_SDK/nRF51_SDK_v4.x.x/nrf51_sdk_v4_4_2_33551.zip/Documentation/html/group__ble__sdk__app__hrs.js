var group__ble__sdk__app__hrs =
[
    [ "main.c", "group__ble__sdk__app__hrs__main.html", "group__ble__sdk__app__hrs__main" ]
];