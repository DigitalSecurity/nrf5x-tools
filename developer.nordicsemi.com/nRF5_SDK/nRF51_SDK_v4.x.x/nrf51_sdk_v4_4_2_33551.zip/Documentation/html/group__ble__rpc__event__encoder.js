var group__ble__rpc__event__encoder =
[
    [ "ble_rpc_event_handle", "group__ble__rpc__event__encoder.html#gaf3705f55729152f62c22adf1a8219df7", null ]
];