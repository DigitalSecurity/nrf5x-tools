var group__ble__rpc__event__encoder__gatts =
[
    [ "ble_rpc_evt_gatts_encode", "group__ble__rpc__event__encoder__gatts.html#ga003647b313a14a7876bd385c0bd1931a", null ]
];