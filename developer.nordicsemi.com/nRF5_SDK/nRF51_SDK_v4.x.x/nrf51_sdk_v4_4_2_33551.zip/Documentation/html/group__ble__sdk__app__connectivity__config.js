var group__ble__sdk__app__connectivity__config =
[
    [ "HCI_SLIP_UART_RX_PIN_NUMBER", "group__ble__sdk__app__connectivity__config.html#ga563b2db0be6fc39f6bdc43275fce4a6c", null ],
    [ "HCI_SLIP_UART_TX_PIN_NUMBER", "group__ble__sdk__app__connectivity__config.html#ga37627f12f64e2d3a9ff5df63fd872003", null ],
    [ "HCI_SLIP_UART_RTS_PIN_NUMBER", "group__ble__sdk__app__connectivity__config.html#gabef88f732922a13c3dc4e3dd514c36fc", null ],
    [ "HCI_SLIP_UART_CTS_PIN_NUMBER", "group__ble__sdk__app__connectivity__config.html#ga9b29fdaf1844f05115940fbf2401fd5f", null ],
    [ "HCI_SLIP_UART_MODE", "group__ble__sdk__app__connectivity__config.html#ga3f2a196e8e6fd828a7408cbce3625a39", null ],
    [ "HCI_SLIP_UART_BAUDRATE", "group__ble__sdk__app__connectivity__config.html#ga32bbc9330e57446dca60392c29857b89", null ],
    [ "MAX_PACKET_SIZE_IN_BITS", "group__ble__sdk__app__connectivity__config.html#ga7f50bc31550595e28cbf7a9eb3597b69", null ],
    [ "USED_BAUD_RATE", "group__ble__sdk__app__connectivity__config.html#ga191602a3878cbd9811815ba22f8fea51", null ]
];