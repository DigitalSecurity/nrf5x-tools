var group__ble__sdk__app__gzll__ui =
[
    [ "BLE_BUTTON_PIN_NO", "group__ble__sdk__app__gzll__ui.html#gacdfeaa096d65ba2dfac2eb6c9bed4c20", null ],
    [ "GZLL_BUTTON_PIN_NO", "group__ble__sdk__app__gzll__ui.html#gaed8efd5544169ccc40031ff4d641254b", null ],
    [ "GZLL_TX_SUCCESS_LED_PIN_NO", "group__ble__sdk__app__gzll__ui.html#ga4142f96d1dbb569fb9a994b98166a455", null ],
    [ "GZLL_TX_FAIL_LED_PIN_NO", "group__ble__sdk__app__gzll__ui.html#gada01fb9aed0fee5bab36f2584a5a95c6", null ],
    [ "buttons_init", "group__ble__sdk__app__gzll__ui.html#gacef6dd444cb6560da652897ee43ab306", null ],
    [ "leds_init", "group__ble__sdk__app__gzll__ui.html#ga67cfc3137a465e560792490e81365254", null ]
];