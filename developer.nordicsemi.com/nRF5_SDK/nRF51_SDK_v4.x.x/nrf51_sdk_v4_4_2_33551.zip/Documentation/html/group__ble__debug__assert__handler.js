var group__ble__debug__assert__handler =
[
    [ "ble_debug_assert_handler", "group__ble__debug__assert__handler.html#ga516d223d23265c3c1095e1543d3691ae", null ]
];