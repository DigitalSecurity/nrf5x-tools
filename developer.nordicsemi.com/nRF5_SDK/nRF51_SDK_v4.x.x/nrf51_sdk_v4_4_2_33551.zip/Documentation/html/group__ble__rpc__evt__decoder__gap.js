var group__ble__rpc__evt__decoder__gap =
[
    [ "ble_rpc_gap_evt_length_decode", "group__ble__rpc__evt__decoder__gap.html#ga4ed930dc79fa0139bae1b3801d790f3d", null ],
    [ "ble_rpc_gap_evt_packet_decode", "group__ble__rpc__evt__decoder__gap.html#gaad1efdc9cfd410bd3b7e7fb08123c42f", null ]
];