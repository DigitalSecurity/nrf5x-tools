var group__ant__hrm__rx__example =
[
    [ "hrm_page0_data_t", "structhrm__page0__data__t.html", [
      [ "beat_count", "structhrm__page0__data__t.html#a9d3d0fd6f34c04617c902bed91bef398", null ],
      [ "computed_heart_rate", "structhrm__page0__data__t.html#a02f15f1b294735977259856af8a51395", null ],
      [ "beat_time", "structhrm__page0__data__t.html#aca0cb9ebeabb10bf7d275febf4b8600d", null ]
    ] ],
    [ "hrm_page1_data_t", "structhrm__page1__data__t.html", [
      [ "operating_time", "structhrm__page1__data__t.html#ae5079276bf774d83b7808310ad33e07b", null ]
    ] ],
    [ "hrm_page2_data_t", "structhrm__page2__data__t.html", [
      [ "manuf_id", "structhrm__page2__data__t.html#a1d512e40a71e4f4320469e57de2e7df2", null ],
      [ "serial_num", "structhrm__page2__data__t.html#a7c726d568291d694e28ffddf81e356bd", null ]
    ] ],
    [ "hrm_page3_data_t", "structhrm__page3__data__t.html", [
      [ "hw_version", "structhrm__page3__data__t.html#aef0fcec04ecbb93297198dd84ccaa790", null ],
      [ "sw_version", "structhrm__page3__data__t.html#a787b355f4c4669f102d22d5a0e17cb48", null ],
      [ "model_num", "structhrm__page3__data__t.html#aa2df4864b23c4dc18d72772b89a315cb", null ]
    ] ],
    [ "hrm_page4_data_t", "structhrm__page4__data__t.html", [
      [ "prev_beat", "structhrm__page4__data__t.html#a97e5a57024d9803171975986edbcee90", null ]
    ] ],
    [ "ANT_EVENT_MSG_BUFFER_MIN_SIZE", "group__ant__hrm__rx__example.html#ga1e6aab925714ececeb76e631d61de98a", null ],
    [ "UART_TX_BUF_SIZE", "group__ant__hrm__rx__example.html#ga399dab7fb34a7513ec04c6a5788e5a45", null ],
    [ "UART_RX_BUF_SIZE", "group__ant__hrm__rx__example.html#ga1f25fe45d891de244a8135ae02fc9265", null ],
    [ "PROTOCOL_EVENT_IRQHandler", "group__ant__hrm__rx__example.html#ga775d723707b1c8b12c5fece5c2e04a0a", null ],
    [ "softdevice_assert_callback", "group__ant__hrm__rx__example.html#gad6bcd9470575d05e10b8d37c7c4b986e", null ],
    [ "app_error_handler", "group__ant__hrm__rx__example.html#gad8b5b293dfa06cbbfeb03aaaaa2772cf", null ],
    [ "main", "group__ant__hrm__rx__example.html#ga840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "hrm_rx_open", "group__ant__hrm__rx__example.html#ga00d8316831629c900d675ff89ceb08be", null ],
    [ "hrm_rx_channel_event_handle", "group__ant__hrm__rx__example.html#gabd24559a2f291ae53ac0fc71d5398c0f", null ]
];