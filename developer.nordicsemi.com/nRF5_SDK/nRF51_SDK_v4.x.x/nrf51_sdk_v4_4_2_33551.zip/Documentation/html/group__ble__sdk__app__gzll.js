var group__ble__sdk__app__gzll =
[
    [ "Bluetooth part of Multiprotocol Application", "group__ble__sdk__app__gzll__bluetooth__part.html", "group__ble__sdk__app__gzll__bluetooth__part" ],
    [ "Common definitions for BLE and Gazell", "group__ble__sdk__app__gzll__common.html", "group__ble__sdk__app__gzll__common" ],
    [ "Gazell part of Multiprotocol Application", "group__ble__sdk__app__gzll__gazell__part.html", "group__ble__sdk__app__gzll__gazell__part" ],
    [ "Multiprotocol Application User Interface", "group__ble__sdk__app__gzll__ui.html", "group__ble__sdk__app__gzll__ui" ],
    [ "main.c", "group__ble__sdk__app__gzll__main.html", "group__ble__sdk__app__gzll__main" ]
];