var group__app__scheduler =
[
    [ "APP_SCHED_EVENT_HEADER_SIZE", "group__app__scheduler.html#ga6ec6d3a526d13df66e0aff7d20049e20", null ],
    [ "APP_SCHED_BUF_SIZE", "group__app__scheduler.html#ga197748a0733d615e809ce71effa6dc48", null ],
    [ "APP_SCHED_INIT", "group__app__scheduler.html#gaa9670ed0053a67304c3d2d0cb3eb1333", null ],
    [ "app_sched_event_handler_t", "group__app__scheduler.html#gad36ea5cb15b82aa724a13f1ba24ef005", null ],
    [ "app_sched_init", "group__app__scheduler.html#gaf021e02dd6ca1767b428c250d1ded56c", null ],
    [ "app_sched_execute", "group__app__scheduler.html#gab725820c32a8d05379db4567cf30e862", null ],
    [ "app_sched_event_put", "group__app__scheduler.html#ga49ec0ad278ece44b5dc56b86ac44489c", null ]
];