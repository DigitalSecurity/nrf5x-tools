var group__adns2080__example__main =
[
    [ "MOTION_INTERRUPT_PIN_NUMBER", "group__adns2080__example__main.html#gac00d3901322b185ce43c8880002d5cec", null ],
    [ "MOUSE_MOVEMENT_THRESHOLD", "group__adns2080__example__main.html#gab40852b1215a406349ec1921d2d4f53a", null ],
    [ "gpiote_init", "group__adns2080__example__main.html#gad22626704ea5d45f863163500e355cc3", null ],
    [ "GPIOTE_IRQHandler", "group__adns2080__example__main.html#ga26b108e2296d5514a2391960b4231d71", null ],
    [ "main", "group__adns2080__example__main.html#ga840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "m_delta_x", "group__adns2080__example__main.html#ga739645fd905c0e19ec6a93609205fd5d", null ],
    [ "m_delta_y", "group__adns2080__example__main.html#gab44d8c3d8e8c57e752ff5c17561021ef", null ],
    [ "motion_interrupt_detected", "group__adns2080__example__main.html#ga4751f749a53b728f17460a69cf06d225", null ]
];