var group__ble__sdk__lib__sensorsim =
[
    [ "ble_sensorsim_cfg_t", "structble__sensorsim__cfg__t.html", [
      [ "min", "structble__sensorsim__cfg__t.html#a0de4531998c77245b8866f2ba909d0fa", null ],
      [ "max", "structble__sensorsim__cfg__t.html#a43e74ba18dc1a237d9f7737ce8df350e", null ],
      [ "incr", "structble__sensorsim__cfg__t.html#a4eed0a83fb9e9824223f835e2b7b3032", null ],
      [ "start_at_max", "structble__sensorsim__cfg__t.html#a91158ca4700058aaa6a54de96b67146a", null ]
    ] ],
    [ "ble_sensorsim_state_t", "structble__sensorsim__state__t.html", [
      [ "current_val", "structble__sensorsim__state__t.html#a65ffdc5d0d2b53bda8497ecafbb0c20d", null ],
      [ "is_increasing", "structble__sensorsim__state__t.html#a824c606f6b930d51e44a6f8f0a96a9f3", null ]
    ] ],
    [ "ble_sensorsim_init", "group__ble__sdk__lib__sensorsim.html#ga87dbeaec725800b329897a89763da807", null ],
    [ "ble_sensorsim_measure", "group__ble__sdk__lib__sensorsim.html#gae73b8f0f956e0708e16d160605318ba8", null ]
];