var group__ble__rpc__cmd__decoder__gatts =
[
    [ "ble_rpc_cmd_gatts_decode", "group__ble__rpc__cmd__decoder__gatts.html#ga517bd09583d7ed0d132e6a47e1dc257b", null ]
];