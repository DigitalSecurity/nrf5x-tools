var group__ble__sdk__app__connectivity =
[
    [ "HCI Transport Layer Configuration", "group__ble__sdk__app__connectivity__config.html", "group__ble__sdk__app__connectivity__config" ],
    [ "main.c", "group__ble__sdk__app__connectivity__main.html", "group__ble__sdk__app__connectivity__main" ]
];