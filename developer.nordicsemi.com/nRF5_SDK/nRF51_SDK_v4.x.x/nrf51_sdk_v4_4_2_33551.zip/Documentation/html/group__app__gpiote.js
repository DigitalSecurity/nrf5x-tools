var group__app__gpiote =
[
    [ "GPIOTE_USER_NODE_SIZE", "group__app__gpiote.html#ga873de058f1a74896f2117c6576e1b4e2", null ],
    [ "NO_OF_PINS", "group__app__gpiote.html#ga9ceabb78fed1102abd4f0f331a04e190", null ],
    [ "APP_GPIOTE_BUF_SIZE", "group__app__gpiote.html#ga1776902d69e12c277659e609fcbf2fe5", null ],
    [ "APP_GPIOTE_INIT", "group__app__gpiote.html#gaed385f30da9f44fb5bf4591eef4d27d9", null ],
    [ "app_gpiote_event_handler_t", "group__app__gpiote.html#ga23c3e3e3c8e271614548b30684a0f4da", null ],
    [ "app_gpiote_init", "group__app__gpiote.html#ga573b71494c38cc4c32b209a13708c78d", null ],
    [ "app_gpiote_user_register", "group__app__gpiote.html#gaa0fe3334c8940d86fc48af00ccb8e0ed", null ],
    [ "app_gpiote_user_enable", "group__app__gpiote.html#ga50622a63550c442d6ad8a8a0d34b166d", null ],
    [ "app_gpiote_user_disable", "group__app__gpiote.html#ga486576266f08b96279e514f080911350", null ],
    [ "app_gpiote_pins_state_get", "group__app__gpiote.html#ga5eaa7bc1dcd21b11a809dbd13b714d75", null ]
];