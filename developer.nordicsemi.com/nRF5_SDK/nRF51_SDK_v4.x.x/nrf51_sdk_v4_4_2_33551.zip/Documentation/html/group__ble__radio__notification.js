var group__ble__radio__notification =
[
    [ "ble_radio_notification_evt_handler_t", "group__ble__radio__notification.html#ga7d22caf17609042ff0c07873c1ad2a13", null ],
    [ "ble_radio_notification_init", "group__ble__radio__notification.html#ga0e02811c4ce9dff7bd190daa42b7a58b", null ]
];