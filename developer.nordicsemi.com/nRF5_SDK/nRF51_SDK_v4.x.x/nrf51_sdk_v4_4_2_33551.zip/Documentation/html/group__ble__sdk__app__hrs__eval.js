var group__ble__sdk__app__hrs__eval =
[
    [ "led.c", "group__ble__sdk__app__hrs__eval__led.html", "group__ble__sdk__app__hrs__eval__led" ],
    [ "main.c", "group__ble__sdk__app__hrs__eval__main.html", "group__ble__sdk__app__hrs__eval__main" ]
];