var group__ble__sdk__app__adv__serialization =
[
    [ "main.c", "group__ble__sdk__app__adv__serialized__main.html", "group__ble__sdk__app__adv__serialized__main" ]
];