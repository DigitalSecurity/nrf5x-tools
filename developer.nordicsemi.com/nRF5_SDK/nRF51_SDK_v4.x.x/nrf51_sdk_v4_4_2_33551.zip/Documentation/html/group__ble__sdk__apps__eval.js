var group__ble__sdk__apps__eval =
[
    [ "Heart Rate Application", "group__ble__sdk__app__hrs__eval.html", "group__ble__sdk__app__hrs__eval" ],
    [ "Proximity Application", "group__ble__sdk__app__proximity__eval.html", "group__ble__sdk__app__proximity__eval" ]
];