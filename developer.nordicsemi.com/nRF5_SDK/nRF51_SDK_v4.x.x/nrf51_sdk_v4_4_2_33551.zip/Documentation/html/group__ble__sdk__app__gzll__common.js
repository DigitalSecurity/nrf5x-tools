var group__ble__sdk__app__gzll__common =
[
    [ "APP_GPIOTE_MAX_USERS", "group__ble__sdk__app__gzll__common.html#ga5ed22f8f4e1728b3e52e861b87ca66c4", null ],
    [ "APP_TIMER_PRESCALER", "group__ble__sdk__app__gzll__common.html#ga7bbff5bb0ca047b109e70a831f08e217", null ],
    [ "APP_TIMER_MAX_TIMERS", "group__ble__sdk__app__gzll__common.html#gad5accf4f59399fd2dd980e1569deac3e", null ],
    [ "APP_TIMER_OP_QUEUE_SIZE", "group__ble__sdk__app__gzll__common.html#ga756f526e607f350705dc7a2e05027cf2", null ],
    [ "radio_mode_t", "group__ble__sdk__app__gzll__common.html#ga02da137ef2e7e2a8ff5592e35e3b0f3a", [
      [ "BLE", "group__ble__sdk__app__gzll__common.html#gga02da137ef2e7e2a8ff5592e35e3b0f3aa83ac6cc3119966e1e5a7908c9e2e3b6a", null ],
      [ "GAZELL", "group__ble__sdk__app__gzll__common.html#gga02da137ef2e7e2a8ff5592e35e3b0f3aab300192f09da1fc221d17b66b2aee2ad", null ]
    ] ],
    [ "running_mode", "group__ble__sdk__app__gzll__common.html#gadb18994ed1933edf505eb15f6268f901", null ]
];