var group__ble__sdk__app__gzll__main =
[
    [ "DEAD_BEEF", "group__ble__sdk__app__gzll__main.html#ga9a42d2d5bc11ba49000e048131c96f39", null ],
    [ "app_error_handler", "group__ble__sdk__app__gzll__main.html#gad8b5b293dfa06cbbfeb03aaaaa2772cf", null ],
    [ "assert_nrf_callback", "group__ble__sdk__app__gzll__main.html#ga4df3b6dd09cac7a9c1705e80fcb735cb", null ],
    [ "timers_init", "group__ble__sdk__app__gzll__main.html#ga09658aaa0774820d8f25249d551bc283", null ],
    [ "gpiote_init", "group__ble__sdk__app__gzll__main.html#gad22626704ea5d45f863163500e355cc3", null ],
    [ "power_manage", "group__ble__sdk__app__gzll__main.html#ga3adda2642702fdb99b08992c39494000", null ],
    [ "main", "group__ble__sdk__app__gzll__main.html#ga840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "running_mode", "group__ble__sdk__app__gzll__main.html#gadb18994ed1933edf505eb15f6268f901", null ]
];