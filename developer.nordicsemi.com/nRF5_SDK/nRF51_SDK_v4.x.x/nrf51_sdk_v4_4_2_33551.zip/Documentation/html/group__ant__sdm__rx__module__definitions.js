var group__ant__sdm__rx__module__definitions =
[
    [ "Data buffer indices", "group__sdm__rx__data__buffer__indices.html", "group__sdm__rx__data__buffer__indices" ],
    [ "Data page 2 - Status byte definitions", "group__ant__sdm__rx__page__2__status__byte__definitions.html", "group__ant__sdm__rx__page__2__status__byte__definitions" ],
    [ "GPIO log settings", "group__sdm__rx__gpio__log__settings.html", null ],
    [ "Page number definitions", "group__sdm__rx__page__number__definitions.html", "group__sdm__rx__page__number__definitions" ]
];