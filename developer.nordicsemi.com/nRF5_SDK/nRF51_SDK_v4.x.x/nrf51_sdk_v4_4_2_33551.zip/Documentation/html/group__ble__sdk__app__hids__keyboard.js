var group__ble__sdk__app__hids__keyboard =
[
    [ "main.c", "group__ble__sdk__app__hids__keyboard__main.html", "group__ble__sdk__app__hids__keyboard__main" ]
];