var group__app__error =
[
    [ "APP_ERROR_HANDLER", "group__app__error.html#gace6d059863761677dae5a6b1456a34ba", null ],
    [ "APP_ERROR_CHECK", "group__app__error.html#ga82d00a810dcea7dcc6af469461fb254c", null ],
    [ "APP_ERROR_CHECK_BOOL", "group__app__error.html#ga9e67d9f4978caa34040b31f8fb9d4f58", null ],
    [ "app_error_handler", "group__app__error.html#gad8b5b293dfa06cbbfeb03aaaaa2772cf", null ]
];