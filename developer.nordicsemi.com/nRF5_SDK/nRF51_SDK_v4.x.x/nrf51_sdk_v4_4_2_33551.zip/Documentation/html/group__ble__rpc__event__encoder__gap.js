var group__ble__rpc__event__encoder__gap =
[
    [ "ble_rpc_evt_gap_encode", "group__ble__rpc__event__encoder__gap.html#gaabcd01412c45a9e9aca8faf50d3a7aa5", null ]
];