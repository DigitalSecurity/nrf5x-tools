var group__ble__sdk__app__bootloader__main =
[
    [ "BOOTLOADER_BUTTON_PIN", "group__ble__sdk__app__bootloader__main.html#gaace3925c0276c95062cbdb6354c005b2", null ],
    [ "APP_GPIOTE_MAX_USERS", "group__ble__sdk__app__bootloader__main.html#ga5ed22f8f4e1728b3e52e861b87ca66c4", null ],
    [ "APP_TIMER_PRESCALER", "group__ble__sdk__app__bootloader__main.html#ga7bbff5bb0ca047b109e70a831f08e217", null ],
    [ "APP_TIMER_MAX_TIMERS", "group__ble__sdk__app__bootloader__main.html#gad5accf4f59399fd2dd980e1569deac3e", null ],
    [ "APP_TIMER_OP_QUEUE_SIZE", "group__ble__sdk__app__bootloader__main.html#ga756f526e607f350705dc7a2e05027cf2", null ],
    [ "BUTTON_DETECTION_DELAY", "group__ble__sdk__app__bootloader__main.html#gaa2008f97369b7247def4cf268d36915c", null ],
    [ "app_error_handler", "group__ble__sdk__app__bootloader__main.html#gad8b5b293dfa06cbbfeb03aaaaa2772cf", null ],
    [ "assert_nrf_callback", "group__ble__sdk__app__bootloader__main.html#ga4df3b6dd09cac7a9c1705e80fcb735cb", null ],
    [ "leds_init", "group__ble__sdk__app__bootloader__main.html#ga0892e076b365fc49b55bd0f90ab09222", null ],
    [ "leds_off", "group__ble__sdk__app__bootloader__main.html#ga80537d2a8e2c30fb0c4faa1bc758766e", null ],
    [ "gpiote_init", "group__ble__sdk__app__bootloader__main.html#gad22626704ea5d45f863163500e355cc3", null ],
    [ "timers_init", "group__ble__sdk__app__bootloader__main.html#ga09658aaa0774820d8f25249d551bc283", null ],
    [ "buttons_init", "group__ble__sdk__app__bootloader__main.html#ga265c25c068555fbfae4ab4f391060040", null ],
    [ "main", "group__ble__sdk__app__bootloader__main.html#ga840291bc02cba5474a4cb46a9b9566fe", null ]
];