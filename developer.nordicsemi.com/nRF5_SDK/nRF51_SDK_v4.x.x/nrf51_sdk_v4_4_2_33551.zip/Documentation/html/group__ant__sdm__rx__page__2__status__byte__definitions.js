var group__ant__sdm__rx__page__2__status__byte__definitions =
[
    [ "SDM_STATUS_USE_STATE_POS", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga668b325932d994461bd810e3a85b375a", null ],
    [ "SDM_STATUS_USE_STATE_MASK", "group__ant__sdm__rx__page__2__status__byte__definitions.html#gaf357889d26572f320e08e515586a2f6f", null ],
    [ "SDM_STATUS_USE_STATE_INACTIVE", "group__ant__sdm__rx__page__2__status__byte__definitions.html#gaa593856698de5f9c6bd8e623332098bc", null ],
    [ "SDM_STATUS_USE_STATE_ACTIVE", "group__ant__sdm__rx__page__2__status__byte__definitions.html#gad7c375f44dded0226bba22a8313f5464", null ],
    [ "SDM_STATUS_HEALTH_POS", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga561fad7dffcbdaf8aa460086b262c278", null ],
    [ "SDM_STATUS_HEALTH_MASK", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga1b85993518640b0746bdb4b07796b544", null ],
    [ "SDM_STATUS_HEALTH_OK", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga92ab607e5415e23f80bce4a42dcadfd6", null ],
    [ "SDM_STATUS_HEALTH_ERROR", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga9e09658a5c3e72f9c837e3a8f426b0d8", null ],
    [ "SDM_STATUS_HEALTH_WARNING", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga58b9c5ca2d600844ad6c741235fa02a8", null ],
    [ "SDM_STATUS_BATTERY_POS", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga4761ce9a6d9b3d03a9e0e04f417500e5", null ],
    [ "SDM_STATUS_BATTERY_MASK", "group__ant__sdm__rx__page__2__status__byte__definitions.html#gaf1f882b3dbfbe08be779bb6a7286de5f", null ],
    [ "SDM_STATUS_BATTERY_NEW", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga766b5384be1315921a709589993230d2", null ],
    [ "SDM_STATUS_BATTERY_STATUS_GOOD", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga1181e3d7af3d75635bcf4e910b8841cc", null ],
    [ "SDM_STATUS_BATTERY_STATUS_OK", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga1e65388783dd5dead1ad178bd0b4408a", null ],
    [ "SDM_STATUS_BATTERY_STATUS_LOW", "group__ant__sdm__rx__page__2__status__byte__definitions.html#gaf8283fe1e185cf1f0431fe9f2d00e4ed", null ],
    [ "SDM_STATUS_LOCATION_POS", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga890001b81afcf262319584f7d8f521ad", null ],
    [ "SDM_STATUS_LOCATION_MASK", "group__ant__sdm__rx__page__2__status__byte__definitions.html#gad1347cbb02b7365c879fea9459c4f2d5", null ],
    [ "SDM_STATUS_LOCATION_LACES", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga768f0fe1f5f57c6a5cc05bd479e0f31a", null ],
    [ "SDM_STATUS_LOCATION_MIDSOLE", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga492b8bc8e3a23f904630dff170137941", null ],
    [ "SDM_STATUS_LOCATION_OTHER", "group__ant__sdm__rx__page__2__status__byte__definitions.html#gaed468ce9159dab28a903889037e92a33", null ],
    [ "SDM_STATUS_LOCATION_ANKLE", "group__ant__sdm__rx__page__2__status__byte__definitions.html#ga06116990e97e19562953c68ebe7d7bea", null ]
];