var group__ble__rpc__evt__decoder =
[
    [ "ble_rpc_event_pkt_received", "group__ble__rpc__evt__decoder.html#ga989d47213c4134eab31a6e9e7629457e", null ]
];