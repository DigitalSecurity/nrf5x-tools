var group__ble__sdk__app__hrs__eval__led =
[
    [ "PPI_CHAN0_TO_TOGGLE_LED", "group__ble__sdk__app__hrs__eval__led.html#ga80f81a2f3b5f5e1642c38bf65eeaedf1", null ],
    [ "GPIOTE_CHAN_FOR_LED_TASK", "group__ble__sdk__app__hrs__eval__led.html#ga79bf7625596d78764844d19ef2a59021", null ],
    [ "TIMER_PRESCALER", "group__ble__sdk__app__hrs__eval__led.html#gaa7914b8d7fd0bae056b85acb5062676b", null ],
    [ "CAPTURE_COMPARE_0_VALUE", "group__ble__sdk__app__hrs__eval__led.html#gaf5c81cd7fdbb7fdce40872b70c95067b", null ],
    [ "timer1_init", "group__ble__sdk__app__hrs__eval__led.html#ga43132496bef9b695b89b05793586aa27", null ],
    [ "ppi_init", "group__ble__sdk__app__hrs__eval__led.html#gaad16890c50156256e260b5205571ddc4", null ]
];