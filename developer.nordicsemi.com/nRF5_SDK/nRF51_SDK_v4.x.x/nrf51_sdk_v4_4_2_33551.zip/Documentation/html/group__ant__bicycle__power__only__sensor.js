var group__ant__bicycle__power__only__sensor =
[
    [ "antplus_event_return_t", "structantplus__event__return__t.html", [
      [ "event", "structantplus__event__return__t.html#a6216a9b36e410d8b4281b0218013f8ed", null ],
      [ "param1", "structantplus__event__return__t.html#a6b082642f454e4c26894199529b919ab", null ]
    ] ],
    [ "UART_TX_BUF_SIZE", "group__ant__bicycle__power__only__sensor.html#ga399dab7fb34a7513ec04c6a5788e5a45", null ],
    [ "UART_RX_BUF_SIZE", "group__ant__bicycle__power__only__sensor.html#ga1f25fe45d891de244a8135ae02fc9265", null ],
    [ "BP_TX_ANT_CHANNEL", "group__ant__bicycle__power__only__sensor.html#ga72b476d886314125b6c0165c83e44aa2", null ],
    [ "BP_PAGE_1", "group__ant__bicycle__power__only__sensor.html#ga38b881618d6478343c747d880488672c", null ],
    [ "BP_PAGE_16", "group__ant__bicycle__power__only__sensor.html#gadde228df6e0a2cf72c8497f18ad3ac6b", null ],
    [ "COMMON_PAGE_80", "group__ant__bicycle__power__only__sensor.html#ga66afebbba0658e2baeba27dbf022e09f", null ],
    [ "COMMON_PAGE_81", "group__ant__bicycle__power__only__sensor.html#gaf6b52b5e5adc6df7b844c2b18f9b2af4", null ],
    [ "BP_PAGE_RESERVE_BYTE", "group__ant__bicycle__power__only__sensor.html#gacb7f213c0d886c12c5d8652b1c1f0f7f", null ],
    [ "BP_CID_170", "group__ant__bicycle__power__only__sensor.html#gaf7524f7b44da383d6279a131c3590cbe", null ],
    [ "antplus_event_t", "group__ant__bicycle__power__only__sensor.html#gafe099c87e1515c0f3e0adb5c167011d3", [
      [ "ANTPLUS_EVENT_PAGE", "group__foftt__ant__bicycle__power__only__sensor.html#ggafe099c87e1515c0f3e0adb5c167011d3a2615b026a594ac52d8c858a97e63c45e", null ],
      [ "ANTPLUS_EVENT_MAX", "group__foftt__ant__bicycle__power__only__sensor.html#ggafe099c87e1515c0f3e0adb5c167011d3ab7f64d12b032111e228c1423cc7fe51c", null ],
      [ "ANTPLUS_EVENT_NONE", "group__foftt__ant__bicycle__power__only__sensor.html#ggafe099c87e1515c0f3e0adb5c167011d3adccdc9d6d0d72f02aeec7c9c1fb463e2", null ],
      [ "ANTPLUS_EVENT_CALIBRATION_REQUEST", "group__foftt__ant__bicycle__power__only__sensor.html#ggafe099c87e1515c0f3e0adb5c167011d3a214e999cb9ce3fb09649e4b341f844b8", null ],
      [ "ANTPLUS_EVENT_PAGE", "group__foftt__ant__bicycle__power__only__sensor.html#ggafe099c87e1515c0f3e0adb5c167011d3a2615b026a594ac52d8c858a97e63c45e", null ],
      [ "ANTPLUS_EVENT_MAX", "group__foftt__ant__bicycle__power__only__sensor.html#ggafe099c87e1515c0f3e0adb5c167011d3ab7f64d12b032111e228c1423cc7fe51c", null ],
      [ "ANTPLUS_EVENT_NONE", "group__foftt__ant__bicycle__power__only__sensor.html#ggafe099c87e1515c0f3e0adb5c167011d3adccdc9d6d0d72f02aeec7c9c1fb463e2", null ],
      [ "ANTPLUS_EVENT_CALIBRATION_REQUEST", "group__foftt__ant__bicycle__power__only__sensor.html#ggafe099c87e1515c0f3e0adb5c167011d3a214e999cb9ce3fb09649e4b341f844b8", null ]
    ] ],
    [ "softdevice_assert_callback", "group__ant__bicycle__power__only__sensor.html#ga3a197364a6f8c23a3372f8b7db0661a0", null ],
    [ "app_error_handler", "group__ant__bicycle__power__only__sensor.html#gad8b5b293dfa06cbbfeb03aaaaa2772cf", null ],
    [ "softdevice_setup", "group__ant__bicycle__power__only__sensor.html#ga2adc15c21c18794fcc708c9955f5469f", null ],
    [ "main", "group__ant__bicycle__power__only__sensor.html#gae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "bp_only_tx_initialize", "group__ant__bicycle__power__only__sensor.html#ga456059ab79782360f67eca121dbf027a", null ],
    [ "bp_only_tx_channel_event_handle", "group__ant__bicycle__power__only__sensor.html#ga3ec06f403f9bd363cf256328964f2730", null ],
    [ "bp_only_tx_power_increment", "group__ant__bicycle__power__only__sensor.html#ga3393be7390866c9fc13133ee230dbe19", null ],
    [ "bp_only_tx_power_decrement", "group__ant__bicycle__power__only__sensor.html#gaa0cad22795177cb6a50041a72b65a9ae", null ],
    [ "bp_only_tx_calib_resp_transmit", "group__ant__bicycle__power__only__sensor.html#ga04ace62ca98655f309ae7615cf251671", null ],
    [ "bp_only_tx_main_loop_run", "group__ant__bicycle__power__only__sensor.html#ga38725c37a371866f9b2f53e4d4a3e19f", null ]
];