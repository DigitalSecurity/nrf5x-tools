var group__ble__sdk__app__pwr__mgmt =
[
    [ "main.c", "group__ble__sdk__app__pwr__mgmt__main.html", "group__ble__sdk__app__pwr__mgmt__main" ]
];