var group__ble__rpc__cmd__decoder =
[
    [ "ble_rpc_cmd_resp_send", "group__ble__rpc__cmd__decoder.html#gaa1540fe2d54b502a7a4b5b387e365907", null ],
    [ "ble_rpc_cmd_resp_data_send", "group__ble__rpc__cmd__decoder.html#ga8a58034cb0d542ba4cf7efd40d73320e", null ],
    [ "ble_rpc_cmd_handle", "group__ble__rpc__cmd__decoder.html#ga14c82a78c0fff524b1f92795a30acbe0", null ]
];