var group__ble__sdk__app__gzll__bluetooth__part =
[
    [ "ble_stack_start", "group__ble__sdk__app__gzll__bluetooth__part.html#ga91945dae4e6f515c9287b64767134b82", null ],
    [ "ble_stack_stop", "group__ble__sdk__app__gzll__bluetooth__part.html#ga91fbf50ad9943de5c7ae04c94a870b2b", null ],
    [ "ble_hrs_app_start", "group__ble__sdk__app__gzll__bluetooth__part.html#gae21e1b6b0891b57113e809204c1ba030", null ],
    [ "ble_hrs_app_stop", "group__ble__sdk__app__gzll__bluetooth__part.html#ga80e3bf60e6957993c026e0da503e832f", null ]
];