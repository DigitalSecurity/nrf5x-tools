var group__ble__types =
[
    [ "Defines", "group___b_l_e___c_o_m_m_o_n___d_e_f_i_n_e_s.html", "group___b_l_e___c_o_m_m_o_n___d_e_f_i_n_e_s" ],
    [ "ble_uuid128_t", "structble__uuid128__t.html", [
      [ "uuid128", "structble__uuid128__t.html#a306a392584201e8684f3fa7fc8fc50fd", null ]
    ] ],
    [ "ble_uuid_t", "structble__uuid__t.html", [
      [ "uuid", "structble__uuid__t.html#aaa1ded1f77a9c12a196ed4ba2ce5f95d", null ],
      [ "type", "structble__uuid__t.html#a1d127017fb298b889f4ba24752d08b8e", null ]
    ] ]
];