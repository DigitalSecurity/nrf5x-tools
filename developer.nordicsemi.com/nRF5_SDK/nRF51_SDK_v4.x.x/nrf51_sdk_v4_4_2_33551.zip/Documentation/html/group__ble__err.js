var group__ble__err =
[
    [ "Error Codes", "group___b_l_e___e_r_r_o_r_s.html", "group___b_l_e___e_r_r_o_r_s" ],
    [ "Module specific error code subranges", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s.html", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s" ]
];