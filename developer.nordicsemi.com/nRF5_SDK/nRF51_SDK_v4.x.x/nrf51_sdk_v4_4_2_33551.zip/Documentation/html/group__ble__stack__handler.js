var group__ble__stack__handler =
[
    [ "BLE_STACK_HANDLER_SCHED_EVT_SIZE", "group__ble__stack__handler.html#ga5cdd71430c9268465e479ababfa08dc3", null ],
    [ "BLE_STACK_HANDLER_INIT", "group__ble__stack__handler.html#ga4e6de5c90e343b0316d6d6410eed95a9", null ],
    [ "ble_stack_evt_handler_t", "group__ble__stack__handler.html#gacd79ddaf9563b5a83383bcffff74c1f3", null ],
    [ "ble_stack_evt_schedule_func_t", "group__ble__stack__handler.html#ga256832aeb0094dac0a7b3427a53cb520", null ],
    [ "ble_stack_handler_init", "group__ble__stack__handler.html#gadda2f944206e8b507eff13a3b37b2f2f", null ]
];