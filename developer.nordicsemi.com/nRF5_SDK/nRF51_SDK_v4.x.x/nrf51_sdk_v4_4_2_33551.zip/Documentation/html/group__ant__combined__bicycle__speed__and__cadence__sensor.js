var group__ant__combined__bicycle__speed__and__cadence__sensor =
[
    [ "UART_TX_BUF_SIZE", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#ga399dab7fb34a7513ec04c6a5788e5a45", null ],
    [ "UART_RX_BUF_SIZE", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#ga1f25fe45d891de244a8135ae02fc9265", null ],
    [ "CBSC_TX_ANT_CHANNEL", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#ga47b1139ccd70b32b25606596842f9c83", null ],
    [ "softdevice_assert_callback", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#gad6bcd9470575d05e10b8d37c7c4b986e", null ],
    [ "app_error_handler", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#gad8b5b293dfa06cbbfeb03aaaaa2772cf", null ],
    [ "softdevice_setup", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#ga2adc15c21c18794fcc708c9955f5469f", null ],
    [ "main", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#ga840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "cbsc_tx_initialize", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#gad63b427d5ba73550791b2e4ef03f3f74", null ],
    [ "cbsc_tx_channel_event_handle", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#ga3fcf0ee545f4d5b43f785ca1b923e568", null ],
    [ "main_cbsc_tx_run", "group__ant__combined__bicycle__speed__and__cadence__sensor.html#ga05837900a61127d85a6823e8dd687c11", null ]
];