var group__ble__sdk__app__dtm__serial =
[
    [ "main.c", "group__dtm__standalone.html", "group__dtm__standalone" ]
];