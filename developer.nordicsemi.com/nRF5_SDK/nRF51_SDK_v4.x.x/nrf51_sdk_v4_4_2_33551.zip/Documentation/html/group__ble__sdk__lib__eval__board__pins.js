var group__ble__sdk__lib__eval__board__pins =
[
    [ "EVAL_BOARD_LED_0", "group__ble__sdk__lib__eval__board__pins.html#ga6de2c706ab2df3c3854f791168f20d05", null ],
    [ "EVAL_BOARD_LED_1", "group__ble__sdk__lib__eval__board__pins.html#gacecce2b4942e55ab8aba19a135e9f7a0", null ],
    [ "EVAL_BOARD_BUTTON_0", "group__ble__sdk__lib__eval__board__pins.html#ga32afdc4ead9deaf59e6f1acfb664f0dd", null ],
    [ "EVAL_BOARD_BUTTON_1", "group__ble__sdk__lib__eval__board__pins.html#ga184fed2a1c2029ee6232f8be9a5324b4", null ],
    [ "ADVERTISING_LED_PIN_NO", "group__ble__sdk__lib__eval__board__pins.html#gaa488010a3b8ef8e01affbf39150e62c9", null ],
    [ "CONNECTED_LED_PIN_NO", "group__ble__sdk__lib__eval__board__pins.html#gabe1b4281eb70ca4f2841cd3bb0b52ab7", null ]
];