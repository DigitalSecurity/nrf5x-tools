var group__app__fifo =
[
    [ "app_fifo_t", "structapp__fifo__t.html", [
      [ "p_buf", "structapp__fifo__t.html#afeaeee72b488745390daf8d4716e63ea", null ],
      [ "buf_size_mask", "structapp__fifo__t.html#a70632874e2fb363e1cb167075ccfd318", null ],
      [ "read_pos", "structapp__fifo__t.html#a3390eeddd7e83b21eeb2566243c62cd6", null ],
      [ "write_pos", "structapp__fifo__t.html#a704dc86383e33e21dc4efa58180e018b", null ]
    ] ],
    [ "app_fifo_init", "group__app__fifo.html#gafc2ba3545e60f0134689fac2aa87f493", null ],
    [ "app_fifo_put", "group__app__fifo.html#ga76ac40c5174cc17b8b6ebd8d86cf0f0e", null ],
    [ "app_fifo_get", "group__app__fifo.html#gab6292f78e91737ba0df83d6755e0abb9", null ],
    [ "app_fifo_flush", "group__app__fifo.html#ga0944439787b55aafb3288a836efa3b9b", null ]
];