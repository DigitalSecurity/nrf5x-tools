var group__ble__sdk__srv__tps =
[
    [ "ble_tps_init_t", "structble__tps__init__t.html", [
      [ "initial_tx_power_level", "structble__tps__init__t.html#abd96f92499bb2a5fb13a1ba721c6feb1", null ],
      [ "tps_attr_md", "structble__tps__init__t.html#a258c687c7b07c69a197c16c542e83b1d", null ]
    ] ],
    [ "ble_tps_t", "structble__tps__t.html", [
      [ "service_handle", "structble__tps__t.html#a363e00d9262febd8d752ed2f933be1e4", null ],
      [ "tx_power_level_handles", "structble__tps__t.html#ae383913d886f91df5c52b1a913efd5b9", null ]
    ] ],
    [ "ble_tps_init", "group__ble__sdk__srv__tps.html#gadf50170201ca904944d8ba0ecb485ba7", null ],
    [ "ble_tps_tx_power_level_set", "group__ble__sdk__srv__tps.html#ga6fccb23ed9c10d23d370e5709cdf6d9f", null ]
];