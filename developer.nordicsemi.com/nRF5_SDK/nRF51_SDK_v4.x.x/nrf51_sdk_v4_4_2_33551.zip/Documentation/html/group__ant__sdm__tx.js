var group__ant__sdm__tx =
[
    [ "Definitions", "group__ant__sdm__tx__module__definitions.html", "group__ant__sdm__tx__module__definitions" ],
    [ "Interface", "group__ant__sdm__tx__module__interface.html", "group__ant__sdm__tx__module__interface" ],
    [ "SDM TX module error codes", "group__ant__sdm__tx__module__error__codes.html", "group__ant__sdm__tx__module__error__codes" ],
    [ "main.c", "group__ant__sdm__tx__example.html", "group__ant__sdm__tx__example" ]
];