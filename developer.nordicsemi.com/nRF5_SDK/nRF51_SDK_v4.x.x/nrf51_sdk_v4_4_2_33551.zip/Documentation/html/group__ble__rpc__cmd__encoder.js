var group__ble__rpc__cmd__encoder =
[
    [ "cmd_response_t", "structcmd__response__t.html", [
      [ "op_code", "structcmd__response__t.html#a52f5d121921fededbdbea9127fc7b62b", null ],
      [ "err_code", "structcmd__response__t.html#a20d3d7867d5207a846cf598532ca353f", null ]
    ] ],
    [ "ble_rpc_cmd_encoder_init", "group__ble__rpc__cmd__encoder.html#ga87a55e10b0272b6a3973dd13aef18a3d", null ],
    [ "ble_rpc_cmd_resp_wait", "group__ble__rpc__cmd__encoder.html#gaf95955905ddcfacecd49c7ebae13c850", null ],
    [ "ble_rpc_cmd_rsp_pkt_received", "group__ble__rpc__cmd__encoder.html#ga01211ec1403c7db7bdfc8a06c267ac4c", null ]
];