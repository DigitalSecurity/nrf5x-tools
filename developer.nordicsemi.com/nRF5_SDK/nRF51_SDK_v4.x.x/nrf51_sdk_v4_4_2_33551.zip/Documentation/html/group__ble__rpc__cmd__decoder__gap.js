var group__ble__rpc__cmd__decoder__gap =
[
    [ "ble_rpc_cmd_gap_decode", "group__ble__rpc__cmd__decoder__gap.html#gabe0d047b0a30da9dceb79f80bebecd70", null ]
];