var group__ant__sdm__tx__module__interface =
[
    [ "sdm_tx_init", "group__ant__sdm__tx__module__interface.html#ga3f6e5e93ba3cfcbea3e01ca84ffac4f8", null ],
    [ "sdm_tx_next_page_num_get", "group__ant__sdm__tx__module__interface.html#gaf4db111c44b24778292e7d189d3321ec", null ],
    [ "sdm_tx_broadcast_data_set", "group__ant__sdm__tx__module__interface.html#ga2ef1006dc3e421351788e5943912ed8e", null ],
    [ "sdm_tx_sensor_data_update", "group__ant__sdm__tx__module__interface.html#ga0d7775e18c052a3a49c7fb56d76c3ec9", null ],
    [ "sdm_tx_log", "group__ant__sdm__tx__module__interface.html#ga73ac6638b52dc8a98f9599d9d10f0d12", null ]
];