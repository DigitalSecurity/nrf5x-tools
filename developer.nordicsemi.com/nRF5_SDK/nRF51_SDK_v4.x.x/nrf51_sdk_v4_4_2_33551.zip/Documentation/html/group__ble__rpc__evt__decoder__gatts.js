var group__ble__rpc__evt__decoder__gatts =
[
    [ "ble_rpc_gatts_evt_length_decode", "group__ble__rpc__evt__decoder__gatts.html#gaf15865dc75fe2ba0941187c0f92fed63", null ],
    [ "ble_rpc_gatts_evt_packet_decode", "group__ble__rpc__evt__decoder__gatts.html#gad37866570fc62afa9209c8d5e7425e96", null ]
];