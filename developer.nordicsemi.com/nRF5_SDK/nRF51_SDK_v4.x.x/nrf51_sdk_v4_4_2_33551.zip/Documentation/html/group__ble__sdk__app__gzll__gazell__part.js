var group__ble__sdk__app__gzll__gazell__part =
[
    [ "gzll_app_start", "group__ble__sdk__app__gzll__gazell__part.html#ga422e418048ac1521cb4a16f5131c71cc", null ],
    [ "gzll_app_stop", "group__ble__sdk__app__gzll__gazell__part.html#ga9c702692c7ba5c2ece8ddfdc370901a9", null ]
];