var group__ant__sdm__tx__module__error__codes =
[
    [ "SDM_ERROR_BASE_NUM", "group__ant__sdm__tx__module__error__codes.html#ga14c46f93f3061b2f949dc4add78a439b", null ],
    [ "SDM_ERROR_INVALID_PAGE_NUMBER", "group__ant__sdm__tx__module__error__codes.html#ga815969d5fae29f2a9f452e7b1c5ffdd0", null ]
];