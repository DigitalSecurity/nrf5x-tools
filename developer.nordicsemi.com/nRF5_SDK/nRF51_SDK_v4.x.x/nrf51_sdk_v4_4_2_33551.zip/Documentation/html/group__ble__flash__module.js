var group__ble__flash__module =
[
    [ "BLE_FLASH_PAGE_SIZE", "group__ble__flash__module.html#ga1c2559036356cf2f070afe1c7bc55654", null ],
    [ "BLE_FLASH_MAGIC_NUMBER", "group__ble__flash__module.html#ga46bb6e7d63431e4de9be88ae5ac675e7", null ],
    [ "BLE_FLASH_EMPTY_MASK", "group__ble__flash__module.html#ga0974ebbf4b324b9466b55c4e71db0453", null ],
    [ "BLE_FLASH_PAGE_END", "group__ble__flash__module.html#gaad80a1b31add453ba141177eddd972a1", null ],
    [ "ble_flash_page_write", "group__ble__flash__module.html#gaad9a06c84fd13e623c62f6f3fa513e3d", null ],
    [ "ble_flash_page_read", "group__ble__flash__module.html#ga8947fe5a3927f5c5cd56009360c6cc9d", null ],
    [ "ble_flash_page_erase", "group__ble__flash__module.html#gae065fb255456031f76773fac7cc98dc8", null ],
    [ "ble_flash_word_write", "group__ble__flash__module.html#gae2b67af95fa40eef714e18488f926d86", null ],
    [ "ble_flash_block_write", "group__ble__flash__module.html#gaa4b50767cf7b10946a93dfad85f92de3", null ],
    [ "ble_flash_page_addr", "group__ble__flash__module.html#gacf4afc843c17b397cef7c853e462ce19", null ],
    [ "ble_flash_crc16_compute", "group__ble__flash__module.html#ga959dec85f479945f7155e4ae2d842bfb", null ],
    [ "ble_flash_on_radio_active_evt", "group__ble__flash__module.html#ga84845060380a5f13275ce4e2e86615d0", null ]
];