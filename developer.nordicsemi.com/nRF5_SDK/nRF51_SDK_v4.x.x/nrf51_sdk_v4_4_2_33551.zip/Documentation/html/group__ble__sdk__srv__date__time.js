var group__ble__sdk__srv__date__time =
[
    [ "ble_date_time_t", "structble__date__time__t.html", [
      [ "year", "structble__date__time__t.html#a57ca98d8f6d4baf0fe41c583c7dcb0d5", null ],
      [ "month", "structble__date__time__t.html#a3e00faf7fbf9805e9ec4d2edd6339050", null ],
      [ "day", "structble__date__time__t.html#a72369a1087b2aeffe374bb054cb97c12", null ],
      [ "hours", "structble__date__time__t.html#a00a531a34a1d603329df5778f1203ab6", null ],
      [ "minutes", "structble__date__time__t.html#a7acca8be0094a19be6e308ac05924c4f", null ],
      [ "seconds", "structble__date__time__t.html#a46729a903be1a03cdb248fb48d84d4f5", null ]
    ] ]
];