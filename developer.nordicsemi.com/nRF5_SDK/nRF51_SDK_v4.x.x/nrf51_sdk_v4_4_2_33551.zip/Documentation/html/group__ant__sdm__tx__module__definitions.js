var group__ant__sdm__tx__module__definitions =
[
    [ "Configurable common page data", "group__sdm__tx__configurable__common__page__data.html", "group__sdm__tx__configurable__common__page__data" ],
    [ "Data buffer indices", "group__sdm__tx__data__buffer__indices.html", "group__sdm__tx__data__buffer__indices" ],
    [ "Data page 2 - status byte definitions", "group__sdm__tx__page__2__status__byte__definitions.html", "group__sdm__tx__page__2__status__byte__definitions" ],
    [ "GPIO log settings", "group__sdm__tx__gpio__log__settings.html", null ],
    [ "Page number definitions", "group__sdm__tx__page__number__definitions.html", "group__sdm__tx__page__number__definitions" ]
];