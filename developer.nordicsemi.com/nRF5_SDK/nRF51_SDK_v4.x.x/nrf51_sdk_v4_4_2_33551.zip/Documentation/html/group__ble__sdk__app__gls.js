var group__ble__sdk__app__gls =
[
    [ "main.c", "group__ble__sdk__app__gls__main.html", "group__ble__sdk__app__gls__main" ]
];