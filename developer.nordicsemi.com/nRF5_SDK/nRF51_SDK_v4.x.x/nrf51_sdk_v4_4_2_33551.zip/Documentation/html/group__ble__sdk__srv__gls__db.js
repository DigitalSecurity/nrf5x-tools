var group__ble__sdk__srv__gls__db =
[
    [ "ble_gls_db_init", "group__ble__sdk__srv__gls__db.html#ga11a776d3fd91b8260a65ecfd68629899", null ],
    [ "ble_gls_db_num_records_get", "group__ble__sdk__srv__gls__db.html#gae6f7f2899cb93e01209a23f2468e5689", null ],
    [ "ble_gls_db_record_get", "group__ble__sdk__srv__gls__db.html#ga30d6e12419921bdabed1f2436b7cfac6", null ],
    [ "ble_gls_db_record_add", "group__ble__sdk__srv__gls__db.html#gae57fa97c63a33a39ee11b61123016ee9", null ],
    [ "ble_gls_db_record_delete", "group__ble__sdk__srv__gls__db.html#ga57f663101a66de5959d262a01278d3b3", null ]
];