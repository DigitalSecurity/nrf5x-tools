var a00264 =
[
    [ "handle", "a00264.html#af1b50c1fd1d5be05d0d0cf25e0925fd0", null ],
    [ "p_value", "a00264.html#abc4d175e50c98877a9cfce9242409b46", null ]
];