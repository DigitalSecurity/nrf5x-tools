var a00304 =
[
    [ "conn_handle", "a00304.html#ab8700a2ae7c425ac15d6622e66967f74", null ],
    [ "evt_handler", "a00304.html#ad1c46431c0465c0d35c17aef3e184a07", null ],
    [ "hrm_cccd_handle", "a00304.html#aa39c35324a4a66fc088ca76085d2a932", null ],
    [ "hrm_handle", "a00304.html#a77ef344286d863fa38ebd60dc06e5e62", null ]
];