var a00159 =
[
    [ "max_conn_interval", "a00159.html#a4034c78595c1924aa231af3bf7be626f", null ],
    [ "min_conn_interval", "a00159.html#ad146986f079ecc38844c525d0c8fc40b", null ]
];