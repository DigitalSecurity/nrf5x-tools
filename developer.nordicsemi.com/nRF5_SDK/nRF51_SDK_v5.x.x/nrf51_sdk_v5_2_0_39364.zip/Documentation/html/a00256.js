var a00256 =
[
    [ "data", "a00256.html#a247b73abe836281cdfd166453d702bde", null ],
    [ "handle", "a00256.html#a96ee6ce1546af608cf4b3b9d81cd7f09", null ],
    [ "len", "a00256.html#a173be268109e2223c485a9a10a6a9ba3", null ],
    [ "type", "a00256.html#ac1de2368e40b7e4c7eab1fcb770605f2", null ]
];