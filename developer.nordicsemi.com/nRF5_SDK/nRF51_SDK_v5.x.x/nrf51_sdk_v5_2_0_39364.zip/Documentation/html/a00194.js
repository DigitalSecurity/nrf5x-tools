var a00194 =
[
    [ "conn_handle", "a00194.html#a38b408b3785dce063725d6fcc194b1c8", null ],
    [ "discovered_db", "a00194.html#a551f5595d71fa2887fa74dff31eb5f40", null ],
    [ "err_code", "a00194.html#aade9f798ada6b7c0f601cb7dfac3d85f", null ],
    [ "evt_type", "a00194.html#accba73434b8696cbafbe758022bb45ec", null ],
    [ "params", "a00194.html#a60aa8e47593f994b163f6a93da35799b", null ]
];