var a00258 =
[
    [ "data", "a00258.html#aa3e65213e96496b82b3afca711e4d221", null ],
    [ "handle", "a00258.html#a54644f05780b15248eba975decdd4e48", null ],
    [ "len", "a00258.html#a5131e80ad4da52f707a84aed7240f2ee", null ],
    [ "offset", "a00258.html#a1ed66c83e153fd6471056d19b10fac67", null ]
];