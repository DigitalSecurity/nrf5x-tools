var a00022 =
[
    [ "Direct Test Mode", "a00030.html", [
      [ "Direct Test Mode", "a00030.html#project_dtm_intro", null ],
      [ "BLE DTM module interface", "a00030.html#ble_sdk_dtm_lib_interface", null ],
      [ "Vendor Specific Packet Payload", "a00030.html#ble_sdk_dtm_proprietary", null ],
      [ "The DTM to Serial adaptation layer", "a00030.html#ble_sdk_dtm_serial2w", null ],
      [ "Running DTM tests", "a00030.html#ble_sdk_dtm_testing", null ]
    ] ]
];