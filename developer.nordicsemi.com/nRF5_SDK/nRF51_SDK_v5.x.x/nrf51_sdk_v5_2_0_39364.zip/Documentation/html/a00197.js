var a00197 =
[
    [ "conn_handle", "a00197.html#aea6b3ca0b15ba3d4684ac2dfaafb584b", null ],
    [ "curr_char_ind", "a00197.html#a2ca30b7a259a7342dc23272fcd6d889f", null ],
    [ "curr_srv_ind", "a00197.html#aa598c16586a07aa4b13e38c35b8b803d", null ],
    [ "discovery_in_progress", "a00197.html#afca8a6f17e6b6d6c40f9fa490ed42b94", null ],
    [ "services", "a00197.html#a982a55a9d1b9f10e010fcebeea5b8911", null ],
    [ "srv_count", "a00197.html#a0cbdc7069a26178c67b3b558633fa261", null ]
];