var a00013 =
[
    [ "Debug Logger", "a00084.html", [
      [ "Initialization", "a00084.html#lib_logger_init", null ],
      [ "Debug Logging", "a00084.html#lib_logger_log", null ],
      [ "Usage by SDK modules and recommendations", "a00084.html#lib_logger_usage", null ]
    ] ]
];