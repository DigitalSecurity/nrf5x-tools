var a00176 =
[
    [ "central_handle", "a00176.html#ad3508eb9ac16f40538396b831984e0de", null ],
    [ "central_id", "a00176.html#a6eb39cbab0fe398d2dd51f30b87ef769", null ],
    [ "evt_type", "a00176.html#a8ec684bfaeab2d840337efaffbba1e19", null ]
];