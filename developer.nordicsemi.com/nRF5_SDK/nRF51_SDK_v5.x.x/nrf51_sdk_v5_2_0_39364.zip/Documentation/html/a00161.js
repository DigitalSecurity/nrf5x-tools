var a00161 =
[
    [ "data", "a00161.html#a401ea8c0aad582a93685a929677b7111", null ],
    [ "service_uuid", "a00161.html#a45ecd97813de71e19a317ee6e0d8e20a", null ]
];