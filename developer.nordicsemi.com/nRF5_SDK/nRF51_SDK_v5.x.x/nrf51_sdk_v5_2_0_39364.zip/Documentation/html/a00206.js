var a00206 =
[
    [ "err_code", "a00206.html#a7399b78d2931ca67335028b94e40fd05", null ],
    [ "failure", "a00206.html#a0cf6e103864e7945f14c1505b813e6d0", null ],
    [ "line_number", "a00206.html#a9d8a550dba94f817123c14d6ca401156", null ],
    [ "message", "a00206.html#aaa3ce88fed3cd597fbd326d647c1b6f8", null ],
    [ "stack_info", "a00206.html#a4355c5cefad7e512433098a13cbcb706", null ]
];