var a00162 =
[
    [ "flags", "a00162.html#aecfc5c6ab14bec2cd20996fe92586a91", null ],
    [ "include_appearance", "a00162.html#a668cb6a3e5c6432618ee2d3a32a167d1", null ],
    [ "name_type", "a00162.html#afe9ec603b1d9f3e868f936464016a3a2", null ],
    [ "p_manuf_specific_data", "a00162.html#a717bae6e0ed091bc095ac081d85c83ed", null ],
    [ "p_service_data_array", "a00162.html#ac6adc467deea02eb86a1a723487fa4ac", null ],
    [ "p_slave_conn_int", "a00162.html#ac9c24c6b54c058265c49b30ae6bcb56a", null ],
    [ "p_tx_power_level", "a00162.html#a3ed830e9c89c1056b955e077656f8b63", null ],
    [ "service_data_count", "a00162.html#a302f506a87a6b735e88b73b8949311cd", null ],
    [ "short_name_len", "a00162.html#a859a4a07ab279923f05b711a540d69ea", null ],
    [ "uuids_complete", "a00162.html#ab4f046bd8319fa2d1f4473f1ac2de28a", null ],
    [ "uuids_more_available", "a00162.html#aca35c2d593094e792ddbe97578456720", null ],
    [ "uuids_solicited", "a00162.html#aff5ba733a44118e90a105eee05ed60f7", null ]
];