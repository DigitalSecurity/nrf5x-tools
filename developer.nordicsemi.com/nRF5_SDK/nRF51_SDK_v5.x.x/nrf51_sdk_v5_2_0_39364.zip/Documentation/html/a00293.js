var a00293 =
[
    [ "max_len", "a00293.html#a021ad724a66d2f8e54c1bdff8def4b4c", null ],
    [ "rep_ref", "a00293.html#af12bb312c4056f52bc2e83ff0ef66233", null ],
    [ "security_mode", "a00293.html#a88082cfc1a5360f43e333ea838257ccb", null ]
];