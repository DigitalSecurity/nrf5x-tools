var a00002 =
[
    [ "UART", "a00096.html", null ],
    [ "TWI", "a00095.html", null ],
    [ "SPI Master", "a00094.html", [
      [ "SPI Module Initialization and Configuration", "a00094.html#spi_master_init", null ],
      [ "SPI Master Data Exchange API", "a00094.html#spi_master_rx_tx", null ]
    ] ]
];