var a00010 =
[
    [ "Architecture", "a00010.html#nrf51_arch_serialization", null ],
    [ "HCI Transport Layer", "a00010.html#nrf51_arch_transport_layer", null ],
    [ "HCI - Transport Layer - System integration", "a00010.html#nrf51_system_integration_serialization", null ],
    [ "BLE S110 Connectivity Chip", "a00008.html", [
      [ "BLE S110 Connectivity Chip", "a00008.html#ble_sdk_app_connectivity_sec", null ],
      [ "Setup", "a00008.html#app_connectivity_setup_serialization", null ]
    ] ],
    [ "Advertising Application Serialized", "a00007.html", [
      [ "Advertising Application Serialized", "a00007.html#ble_sdk_app_adv_serialization_sec", null ],
      [ "Setup", "a00007.html#app_advertising_setup_serialization", null ],
      [ "Testing", "a00007.html#app_advertising_test_serialization", null ]
    ] ],
    [ "Heart Rate Application - Serialized", "a00009.html", [
      [ "Heart Rate Application - Serialized", "a00009.html#ble_sdk_app_hrs_serialized_sec", null ]
    ] ]
];