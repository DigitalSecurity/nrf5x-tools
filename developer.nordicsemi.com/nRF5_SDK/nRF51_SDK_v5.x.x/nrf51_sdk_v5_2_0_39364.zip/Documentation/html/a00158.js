var a00158 =
[
    [ "data", "a00158.html#a9241052870696d4d825c91c4a834a84f", null ],
    [ "error_code", "a00158.html#ab2aeea864de0050ec22790a186a4e9b1", null ],
    [ "error_communication", "a00158.html#ae2f48256edd4052e8273d098bb8249c4", null ],
    [ "evt_type", "a00158.html#ae89e1d236d49d18fa5be6fa32ba3c0d8", null ],
    [ "value", "a00158.html#a9e34eabccc01fe3eeff1c7392d737d84", null ]
];