var a00213 =
[
    [ "fp", "a00213.html#a9e2d44610c896a2d1466eb293688f226", null ],
    [ "interval", "a00213.html#a289b288f81c56920fea9a6373697c7f3", null ],
    [ "p_peer_addr", "a00213.html#a95030142363f03486abece197f908fd7", null ],
    [ "p_whitelist", "a00213.html#a96ed26d440abdd418b691b0ebc313945", null ],
    [ "timeout", "a00213.html#a81b240f5be7e508a84467b7ac2ff6d15", null ],
    [ "type", "a00213.html#aece8d919208244b8085f64b613708427", null ]
];