var a00145 =
[
    [ "date", "a00145.html#a24dc30a971f0b0e243d7887057508bc0", null ],
    [ "length", "a00145.html#a5f236e450b92ae88ff82b87609a187bf", null ],
    [ "reserved01", "a00145.html#a4fd76b9c5a116b9b7a88359e34076b15", null ],
    [ "reserved02", "a00145.html#a4527864389a6440049b64d749ab3f5c3", null ],
    [ "reserved03", "a00145.html#ad90380b578645a738710797955da05e4", null ],
    [ "reserved04", "a00145.html#a06a34e1ae31e499854280baaf734a20c", null ],
    [ "reserved05", "a00145.html#aaa8fce85b39044ad961168f7b9d50c64", null ],
    [ "system_time", "a00145.html#aa5ecd93df8cbd4c011d198bfb7430f29", null ],
    [ "time_format", "a00145.html#a6f5286bc3474d5ff5af428629dadf5bf", null ],
    [ "version", "a00145.html#a0c2c4d0605e133812cde06a03a30d1a9", null ]
];