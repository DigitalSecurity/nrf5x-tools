var a00272 =
[
    [ "char_ext_props", "a00272.html#ac5e56544775870bc0dfcccbfe49546c5", null ],
    [ "char_props", "a00272.html#a3d9381741f1a0b9e3ca5e2a5ddeb6877", null ],
    [ "char_user_desc_max_size", "a00272.html#a5916d5b2468348a72e9dcbdfc8d09404", null ],
    [ "char_user_desc_size", "a00272.html#a1fdf0123a1e5ae6591be0e16879c7bf4", null ],
    [ "p_cccd_md", "a00272.html#ac6788721a323f301f8ca5d384d0fe73a", null ],
    [ "p_char_pf", "a00272.html#a92e14548057fa745978ff939a78ae042", null ],
    [ "p_char_user_desc", "a00272.html#a576499e8e617f3bb66cd86ba35ba079b", null ],
    [ "p_sccd_md", "a00272.html#aadb6a806cd31bdfdc1c23fa4e58caf7b", null ],
    [ "p_user_desc_md", "a00272.html#a34f769fe013c0e6db7e27bf8a9d26c62", null ]
];