var a00193 =
[
    [ "cccd_handle", "a00193.html#a7ec4f43c4adba9c33d6c52fa6637540b", null ],
    [ "characteristic", "a00193.html#ac1bd337f6b1acc35a908b13ee4877a88", null ]
];