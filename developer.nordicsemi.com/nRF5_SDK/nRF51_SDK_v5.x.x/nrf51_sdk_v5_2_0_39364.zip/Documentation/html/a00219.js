var a00219 =
[
    [ "data", "a00219.html#a389279e4505e5f438e39b64cac8ab4c0", null ],
    [ "dlen", "a00219.html#aa1cbdc1d8b21b88f2da188d6eda04f1d", null ],
    [ "peer_addr", "a00219.html#aa3b76d297c95df8244348e7352eca1da", null ],
    [ "rssi", "a00219.html#a9592fc581c5ed9fd84514c32603bb478", null ],
    [ "scan_rsp", "a00219.html#a04da677a8c6811bb291c6e62b0bc34e1", null ],
    [ "type", "a00219.html#a1660789dcb5af05b84771251f2da68e4", null ]
];