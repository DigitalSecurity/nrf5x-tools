var a00016 =
[
    [ "ANT and BLE Heart Rate Monitor Relay Application", "a00092.html", [
      [ "Heart Rate Relay Example", "a00092.html#examples_ant_ble_hrm_relay_intro", null ],
      [ "Setup", "a00092.html#examples_ant_ble_hrm_relay_setup", null ],
      [ "Testing", "a00092.html#examples_ant_ble_hrm_relay_test", null ]
    ] ]
];