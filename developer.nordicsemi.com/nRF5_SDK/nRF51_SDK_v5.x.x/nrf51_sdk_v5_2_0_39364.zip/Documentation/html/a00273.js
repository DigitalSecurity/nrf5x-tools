var a00273 =
[
    [ "desc", "a00273.html#a9133fc1220787c07ac21291dab7b8b22", null ],
    [ "exponent", "a00273.html#a931b1bdd89be7d3aaa1d1522d20c7dd5", null ],
    [ "format", "a00273.html#a9a79d570aa8f758c81ddddbf345b289e", null ],
    [ "name_space", "a00273.html#a279e1e8de47b628414382aed4cec3c68", null ],
    [ "unit", "a00273.html#ab28e4dc2a48e6329df85b3f974cf4466", null ]
];