var a00255 =
[
    [ "count", "a00255.html#a50815a26acf0eaa4a6d7ef9bebf7f58d", null ],
    [ "descs", "a00255.html#a4d2ee434e5c4264bae282bb83c20ee67", null ]
];