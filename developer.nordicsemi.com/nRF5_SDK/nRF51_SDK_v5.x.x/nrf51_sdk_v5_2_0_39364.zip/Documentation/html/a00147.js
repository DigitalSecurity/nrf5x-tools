var a00147 =
[
    [ "head", "a00147.html#a4692352586d87bd200e4c354bad7a1e2", null ],
    [ "p_queue", "a00147.html#a095539812df660360ce4ec755de73e62", null ],
    [ "tail", "a00147.html#a4911aef088e83f7b0b7831df30246be0", null ]
];