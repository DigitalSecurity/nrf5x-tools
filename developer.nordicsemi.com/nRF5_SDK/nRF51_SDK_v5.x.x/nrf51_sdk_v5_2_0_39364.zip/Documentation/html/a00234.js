var a00234 =
[
    [ "addr", "a00234.html#abbebf4e8f11e077613a36c7426e7218a", null ],
    [ "irk", "a00234.html#a818159b719ab0edf4d04494e358bd843", null ]
];