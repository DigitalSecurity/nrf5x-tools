var a00167 =
[
    [ "error_handler", "a00167.html#a595f52194b0dbb3300a9e7dc0f0f360f", null ],
    [ "evt_handler", "a00167.html#aad8ea29f7f384965a82424a4ca3c8e50", null ],
    [ "message_buffer_size", "a00167.html#a0ac3fed59a0cbf329cc6611ab584ef69", null ],
    [ "p_message_buffer", "a00167.html#a146d527b7a4824fb4e4f585e455b14f0", null ]
];