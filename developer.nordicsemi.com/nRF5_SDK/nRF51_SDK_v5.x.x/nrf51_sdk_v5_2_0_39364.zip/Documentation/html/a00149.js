var a00149 =
[
    [ "beacon_device_manufacturing_id", "a00149.html#a07862fc33a2d5eecefc8094322cd59bb", null ],
    [ "beacon_device_type", "a00149.html#a27dab00f84fa08d957ce1f8afeba10b3", null ],
    [ "beacon_frequency", "a00149.html#adde5f25dcfff1f7bba78afeb5d4c9541", null ],
    [ "beacon_status_byte1", "a00149.html#abd92f28b51f5fca0100ff6a2d31a9c5f", null ],
    [ "client_serial_number", "a00149.html#a241352a89c655afae2b422bd1b1b9b66", null ],
    [ "p_pass_key", "a00149.html#a0decc3bf33fd5d99d21ec6c08fdc2026", null ],
    [ "p_remote_friendly_name", "a00149.html#a27597e984b49f563ec66a7cb812f4897", null ]
];