/* Copyright (c) 2012 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 */

#include "ble_cgm_db.h"


typedef struct
{
    bool           in_use_flag;
    ble_cgms_rec_t record;
} database_entry_t;

static database_entry_t m_database[BLE_CGMS_DB_MAX_RECORDS];
static uint8_t          m_database_crossref[BLE_CGMS_DB_MAX_RECORDS];
static uint16_t         m_num_records;


static uint32_t sim_database_init(void);


uint32_t ble_cgms_db_init(void)
{
    int i;

    for (i = 0; i < BLE_CGMS_DB_MAX_RECORDS; i++)
    {
        m_database[i].in_use_flag = false;
        m_database_crossref[i]    = 0xFF;
    }

    m_num_records = 0;

    //---------------------------------------------
    // populate database with simulated data
    {
        uint32_t err_code = sim_database_init();

        if (err_code != NRF_SUCCESS)
        {
            return err_code;
        }
    }
    //---------------------------------------------

    return NRF_SUCCESS;
}


uint16_t ble_cgms_db_num_records_get(void)
{
    return m_num_records;
}


uint32_t ble_cgms_db_record_get(uint8_t record_num, ble_cgms_rec_t * p_rec)
{
    if (record_num >= m_num_records)
    {
        return NRF_ERROR_NOT_FOUND;
    }

    // copy record to the specified memory
    *p_rec = m_database[m_database_crossref[record_num]].record;

    return NRF_SUCCESS;
}


uint32_t ble_cgms_db_record_add(ble_cgms_rec_t * p_rec)
{
    int i;

    if (m_num_records == BLE_CGMS_DB_MAX_RECORDS)
    {
        return NRF_ERROR_NO_MEM;
    }

    // find next available database entry
    for (i = 0; i < BLE_CGMS_DB_MAX_RECORDS; i++)
    {
        if (!m_database[i].in_use_flag)
        {
            m_database[i].in_use_flag = true;
            m_database[i].record      = *p_rec;

            m_database_crossref[m_num_records] = i;
            m_num_records++;

            return NRF_SUCCESS;
        }
    }

    return NRF_ERROR_NO_MEM;
}


uint32_t ble_cgms_db_record_delete(uint8_t record_num)
{
    int i;

    if (record_num >= m_num_records)
    {
        // Deleting a non-existent record is not an error
        return NRF_SUCCESS;
    }

    // free entry
    m_database[m_database_crossref[record_num]].in_use_flag = false;

    // decrease number of records
    m_num_records--;

    // remove cross reference index
    for (i = record_num; i < m_num_records; i++)
    {
        m_database_crossref[i] = m_database_crossref[i + 1];
    }

    return NRF_SUCCESS;
}


/**@brief Glucose service simulated database.
 */
ble_cgms_rec_t sim_gls_recs[] =
{
    // --- sample record #1 ---
    {
      // measurement
      {
          12,  /**< Glucose measurement */
          0,   /**< Time Offset */
          0    /**< Sensor status annunciation */
      },
    },
#if 0    
    // --- sample record #2 ---
    {
      // measurement
      {
          24,   /**< Glucose measurement */
          120,  /**< Time Offset */
          0     /**< Sensor status annunciation */
      },
    },
   
    // --- sample record #3 ---
    {
      // measurement
      {
          36,   /**< Glucose measurement */
          180,  /**< Time Offset */
          0     /**< Sensor status annunciation */
      },
    }
#endif
};


static uint32_t sim_database_init(void)
{
    uint32_t     err_code = NRF_SUCCESS;
    unsigned int i;

    for (i = 0; i < sizeof(sim_gls_recs) / sizeof(ble_cgms_rec_t); i++)
    {
        err_code = ble_cgms_db_record_add(&sim_gls_recs[i]);
        if (err_code != NRF_SUCCESS)
        {
            break;
        }
    }
    return err_code;
}
